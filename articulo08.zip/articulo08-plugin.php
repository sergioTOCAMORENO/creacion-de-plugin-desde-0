<?php

/*
Plugin Name: Tabla de Attachments
Plugin URI: sergiotoca.com
Description: Plugin 8 de la serie de artículos 'Crear un plugin desde 0'. Muestra todos los datos en el back-end
Version: 0.1
Author: Sergio TOCA MORENO
Author URI: sergiotoca.com
Text Domain: stmpujante
Domain Path: /idiomas
*/

	function listar_directorios_ruta( $ruta ){
		global $subidas;
		// abrir un directorio y listarlo recursivo 
		if ( is_dir( $ruta ) ) {
			if ( $dh = opendir( $ruta ) ) {
				//echo "<br>Directorio: $ruta";
				while ( ( $file = readdir( $dh ) ) !== false ) {
					//esta línea la utilizaríamos si queremos listar todo lo que hay en el directorio
					//mostraría tanto archivos como directorios
					//echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nombre de archivo: $file : Es un: " . filetype( $ruta . '/' . $file );
					$subidas[] = array(
						'ruta'		=> $ruta,
						'fichero'	=> $file,
						'vinculado'	=> ''
					);
					if ( is_dir( $ruta . '/' . $file ) && $file != "." && $file != ".." ){
						//solo si el archivo es un directorio, distinto que "." y ".."
						listar_directorios_ruta( $ruta . '/' . $file . '/' );
					}
				}
				closedir($dh);
			}
		} else {
			echo "<br>No es ruta valida. " . $ruta; 
		}
	}

	// 2. Lectura de registros del sistema y relleno de matriz
	function stmpujante_formatos_imagenes() {
	
		global $_wp_additional_image_sizes;
		
		$tamanyos = array();
		
		foreach ( get_intermediate_image_sizes() as $tamanyo ) {
			// Buscamos si es alguno de los originales del core de wordpress
			if ( in_array ( $tamanyo, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
				$tamanyos[$tamanyo]['name'] = $tamanyo;
				$tamanyos[$tamanyo]['width'] = get_option( "{$tamanyo}_size_w" );
				$tamanyos[$tamanyo]['height'] = get_option( "{$tamanyo}_size_h" );

				$tamanyos[$tamanyo]['crop'] = get_option( "{$tamanyo}_crop" );
			} elseif ( isset( $_wp_additional_image_sizes[ $tamanyo ] ) ) {
				// O bien si es un formato custom (plugin o plantilla)
				$tamanyos[ $tamanyo ] = array(
					'name'		=> $tamanyo,
					'width'		=> $_wp_additional_image_sizes[ $tamanyo ]['width'],
					'height'	=> $_wp_additional_image_sizes[ $tamanyo ]['height'],
					'crop'		=> $_wp_additional_image_sizes[ $tamanyo ]['crop'],
				);
			}
		}
	
		return $tamanyos;
	}


add_action( 'admin_menu', 'stmpujante_funcion_crear_submenu' );

function stmpujante_funcion_crear_submenu() {

	add_submenu_page( 'upload.php', __( 'Sistema de gestión de medios', 'stmpujante' ), __( 'STMPujante', 'stmpujante'), 'manage_options', 'menu_stmpujante', 'stmpujante_funcion_crear_pagina' );
	
}
	
function stmpujante_funcion_crear_pagina() {
	
	// Plantilla correspondiente al artículo 8 de la serie 'Crear un plugin desde 0'

	// Esquema:
	// 1. Lectura de archivos del directorio 'uploads' y relleno de matriz
	// 2. Lectura de registros del sistema y relleno de matriz
	// 3. Query de los attachments
	// 4. Recopilación de los metadata
	// 5. Búsqueda de los posts a los que está vinculado un attachment
	// 5. Loop con los attachments
	// 5.1. Mostrar datos principales
	// 5.2. Mostrar sizes attachments
	// 5.3. Confrontar con medidas del sistema
	// 5.4. Confrontar con archivos de 'uploads'. Actualizar en matriz
	// 5.5. Mostrar datos adicionales
	// 5. Mostrar archivos 'uploads' no confrontados.

	// 1. Lectura de archivos del directorio 'uploads' y relleno de matriz
	$upload_dir = wp_upload_dir(); // Array of key => value pairs
	$inicio = str_replace( '\\', '/', urldecode( $upload_dir['basedir'] ) );  // Establecemos la dirección inicial
	$subidas = array();
	listar_directorios_ruta( $inicio ); // Llamamos a la función recursiva con la dirección inicial


	// 3. Query de los attachments
	// Establecemos los argumentos de la consulta...
	$argumentos = array(
		'posts_per_page' => -1,
		'post_type'      => 'attachment',
		'post_status'    => 'any'
	);

	// ... y realizamos la consulta, volcándola en una matriz
	$stmpujante_attachments = get_posts( $argumentos );

	// 4. Recopilación de los metadata
	$stmpujante_metadatos = array();

	foreach ( $stmpujante_attachments as $elemento ) {
	
		$stmpujante_metadatos[ $elemento->ID ] = wp_get_attachment_metadata( $elemento->ID );
	
	}

	// 5. Búsqueda de los posts a los que está vinculado un attachment
	function get_posts_by_attachment_id( $attachment_id ) {
		$used_as_thumbnail = array();

		if ( wp_attachment_is_image( $attachment_id ) ) {
			$thumbnail_query = new WP_Query( array(
				'meta_key'       => '_thumbnail_id',
				'meta_value'     => $attachment_id,
				'post_type'      => 'any',	
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'posts_per_page' => -1,
			) );

			$used_as_thumbnail = $thumbnail_query->posts;
		}

		$attachment_urls = array( wp_get_attachment_url( $attachment_id ) );

		if ( wp_attachment_is_image( $attachment_id ) ) {
			foreach ( get_intermediate_image_sizes() as $size ) {
				$intermediate = image_get_intermediate_size( $attachment_id, $size );
				if ( $intermediate ) {
					$attachment_urls[] = $intermediate['url'];
				}
			}
		}

		$used_in_content = array();

		foreach ( $attachment_urls as $attachment_url ) {
			$content_query = new WP_Query( array(
				's'              => $attachment_url,
				'post_type'      => 'any',	
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'posts_per_page' => -1,
			) );

			$used_in_content = array_merge( $used_in_content, $content_query->posts );
		}

		$used_in_content = array_unique( $used_in_content );

		$posts = array(
			'thumbnail' => $used_as_thumbnail,
			'content'   => $used_in_content,
		);

		return $posts;
	}


	// 5. Loop con los attachments
	// Lo vamos a hacer con tables. Por tanto, debemos empezar con la cabecera
	?>
	<style>
		.resultados-stmpujante {
			@import url('https://fonts.googleapis.com/css?family=Space+Mono');
			font-family: "Space Mono", monospace;
			font-size: 12px;
			width: 96%;
			margin: 0 auto;
		}
		table {
			margin-bottom: 0px;
		}
		.tabla-formatos, .tabla-editables, .tabla-avanzados, .tabla-vinculos {
			border: #000 solid 1px;
		}
		.cabecera {
			font-weight:bold;
			text-align:center;
		}
		td {
			padding: 0px;
		}
		tr {
			border: 0px;
		}
		button {
			font-size: inherit;
			font-weight: normal;
			padding: 2px;
			background-color: gray;
			color: black;
			border: #000 solid 1px;
		}
		.campo {
			display: flex;
		}
		.campo input {
			font-family: "Space Mono", monospace;
			font-size: 12px;
			padding: 3px;
		}
		.izquierda {
			border-left: #000 solid 1px;
		}
		.derecha {
			border-right: #000 solid 1px;
		}
		.arriba {
			border-top: #000 solid 1px;
		}
		.abajo {
			border-bottom: #000 solid 1px;
		}
	
	</style>
	<table class="resultados-stmpujante">
		<tr class="cabecera">
			<td class="masinfo">+</td>
			<td class="id">ID</td>
			<td class="titulo">Título</td>
			<td class="ancho">Ancho</td>
			<td class="alto">Alto</td>
			<td class="ruta">Ruta</td>
			<td class="archivo">Archivo</td>
			<td class="imagen">Imagen</td>
		</tr>
	<?php

	foreach ( $stmpujante_attachments as $elemento ) {
	
		// Primero cojo los datos
		$id = $elemento -> ID;
		$titulo = $elemento -> post_title;
		$ancho = $stmpujante_metadatos[$id]['width'];
		$alto = $stmpujante_metadatos[$id]['height'];
		$nombre = $stmpujante_metadatos[$id]['file'];
		$archivo = $elemento -> guid;
		$ruta = str_replace( $nombre, '', $archivo );
	
		// para luego mostrarlos
		?>
		<tr class="attachment-<?php echo $id; ?>">
			<td class="masinfo-<?php echo $id; ?>">
				<button id="boton-formatos-<?php echo $id; ?>" onclick="funcionVisualizarFormatos(<?php echo $id; ?>)">Formatos</button>
				<button id="boton-editables-<?php echo $id; ?>" onclick="funcionVisualizarEditables(<?php echo $id; ?>)">Editables</button>
				<button id="boton-avanzadas-<?php echo $id; ?>" onclick="funcionVisualizarAvanzadas(<?php echo $id; ?>)">Avanzadas</button>
			</td>
			<td class="id"><?php echo $id; ?></td>
			<td class="titulo"><?php echo $titulo; ?></td>
			<td class="ancho"><?php echo $ancho; ?></td>
			<td class="alto"><?php echo $alto; ?></td>
			<td class="ruta"><?php echo $ruta; ?></td>
			<td class="nombre"><?php echo $nombre; ?></td>
			<td class="imagen"><img src="<?php echo $archivo; ?>" style="height:50px;" ></td>
		</tr>
	
		<?php
	
		// Ahora, vamos a crear la subtabla sizes, la cual compara los registros del sistema con los registros de cada attachment
		$stmpujante_formatos = stmpujante_formatos_imagenes();
		?>
		<tr>
			<td colspan="8">
				<table id="formatos-<?php echo $id; ?>" class="tabla-formatos" style="display: none">
					<tr class="cabecera">
						<td colspan="4" class="izquierda arriba derecha">FORMATOS DEL SISTEMA</td>
						<td colspan="4" class="izquierda arriba derecha">FORMATOS DEL ATTACHMENT</td>
						<td colspan="2" class="izquierda arriba derecha">DIRECTORIO 'UPLOADS'</td>
					</tr>
					<tr class="cabecera">
						<td class="izquierda">Formato</td>
						<td>Ancho</td>
						<td>Alto</td>
						<td class="derecha">Crop</td>
						<td class="izquierda">Ancho</td>
						<td>Alto</td>
						<td>Tipo mime</td>
						<td class="derecha">Fichero</td>
						<td class="izquierda">Ruta</td>
						<td class="derecha">Fichero 'uploads'</td>
					</tr>
				
					<?php
					foreach ( $stmpujante_formatos as $formato_sistema ) {
						$nombre_formato = $formato_sistema['name'];
						$ancho_formato = $formato_sistema['width'];
						$alto_formato = $formato_sistema['height'];
						$recorte_formato = $formato_sistema['crop'];
						?>
						<tr>
							<td class="izquierda"><?php echo $nombre_formato; ?></td>
							<td><?php echo $ancho_formato; ?></td>
							<td><?php echo $alto_formato; ?></td>
							<td class="derecha"><?php echo $recorte_formato; ?></td>
							<?php
							// Entonces, tenemos que buscar en los sizes de los metadatos del attachment las coincidencias
							$formatos_attachment = $stmpujante_metadatos[$id]['sizes'];
							$coincidente = false;
							$contador = -1;
							$indices = array_keys($formatos_attachment);
							foreach ( $formatos_attachment as $formato ) {
								$contador++;
								if ( $indices[$contador] == $nombre_formato ) {
									$ancho_attachment = $formato['width'];
									$alto_attachment = $formato['height'];
									$tipo_attachment = $formato['mime-type'];
									$fichero_attachment = $formato['file'];
									$coincidente = true;
									?>
									<td class="izquierda"><?php echo $ancho_attachment; ?></td>
									<td><?php echo $alto_attachment; ?></td>
									<td><?php echo $tipo_attachment; ?></td>
									<td class="derecha"><?php echo $fichero_attachment; ?></td>
									<?php
									// Finalmente, debemos buscar el archivo de 'uploads'
									$coincidente = false;
									foreach ( $subidas as $subida ) {
										if ( $subida['fichero'] == $fichero_attachment ) {
											$coincidente = true;
											$subida['vinculado'] = 'si';
											?>
											<td class="izquierda"><?php echo $subida['ruta']; ?></td>
											<td class="derecha"><?php echo $subida['fichero']; ?></td>
											</tr>
											<?php
										}
									}
									if ( $coincidente == false ) {
										?>
										<td colspan="2" class="izquierda derecha">No existe en uploads</td>
										<?php
									}
								}
							}
							if ( $coincidente == false ) {
								?>
								<td colspan="4" class="izquierda derecha">No coincidente</td>
								<td colspan="2" class="izquierda derecha"></td>
								<?php
							}
						?>
						</tr>
						<?php		
					}
					// Ahora, recorremos toda la matriz $formatos_attachment para recuperar los formatos no mostrados
					$contador = -1;
					foreach ( $formatos_attachment as $formato ) {
						$coincidente = false;
						$contador++;
						foreach ( $stmpujante_formatos as $formato_sistema ) {
							if ( $indices[$contador] == $formato_sistema['name'] ) {
								$coincidente = true;
							}
						}
					
						if ( $coincidente == false ) {
							?>
							<tr>
								<td colspan="2" class="izquierda">Formato no coincidente</td>
								<td colspan="2" class="derecha"><?php echo $indices[$contador]; ?></td>
								<td class="izquierda"><?php echo $formato['width']; ?></td>
								<td><?php echo $formato['height']; ?></td>
								<td><?php echo $formato['mime-type']; ?></td>
								<td class="derecha"><?php echo $formato['file']; ?></td>
							<?php
							// Finalmente, debemos buscar el archivo de 'uploads
							$coincidente = false;
							foreach ( $subidas as $subida ) {
								if ( $subida['fichero'] == $formato['file'] ) {
									$coincidente = true;
									$subida['vinculado'] = 'si';
									?>
									<td class="izquierda"><?php echo $subida['ruta']; ?></td>
									<td class="derecha"><?php echo $subida['fichero']; ?></td>
									</tr>
									<?php
								}
							}
							if ( $coincidente == false ) {
								?>
								<td colspan="2" class="izquierda derecha">No existe en uploads</td>
								
								<?php
							}
						}
					}
				
				?>
				</table>
			</td>
		</tr>
		<?php
		// Añadimos al final los posts a los que está vinculado como thumbnail o en el contenido
		$total_posts_vinculados = get_posts_by_attachment_id( $id );
		$vinculados_thumbnails = $total_posts_vinculados['thumbnail'];
		$vinculados_contenidos = $total_posts_vinculados['content'];
		?>
		<tr class="vinculos-posts">
			<td colspan="8">
				<table id="vinculos-<?php echo $id; ?>" class="tabla-vinculos" style="display: none;">
					<tr>
					<?php
					if ( count( $vinculados_thumbnails ) == 0 ) {
						?>
						<td colspan="4">
							<p class="cabecera">Vinculado como thumbnail</p>
							No está vinculado
						</td>
						<?php
					} else {
						?>
						<td colspan="4">
							<p class="cabecera">Vinculado como thumbnail</p>
							<?php
							foreach ( $vinculados_thumbnails as $articulo ) {
								echo '<br>' . get_the_title( $articulo );
							}
							?>
						</td>
						<?php
					}
					if ( count( $vinculados_contenidos ) == 0 ) {
						?>
						<td colspan="4">
							<p class="cabecera">Vinculado en el contenido</p>
							No está vinculado
						</td>
						<?php
					} else {
						?>
						<td colspan="4">
							<p class="cabecera">Vinculado en el contenido</p>
							<?php
							foreach ( $vinculados_contenidos as $articulo ) {
								echo '<br>' . get_the_title( $articulo );
							}
							?>
						</td>
						<?php
					}
					?>
					</tr>
				</table>
			</td>
		</tr>
		<?php
		// Ahora, toca el turno de los campos editables, que serán interesantes para mantenimiento SEO
		// Primero, recopilamos los datos
		$leyenda = $elemento -> post_excerpt;
		$descripcion = $elemento -> post_content;
		$permitir_comentarios = $elemento -> comment_status;
		$permitir_pingbacks = $elemento -> ping_status;
		$slug = $elemento -> post_name;
		$autor = $elemento -> post_author;
		$nombre_autor = get_the_author_meta( 'user_nicename', $autor );
		$texto_alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
		// A partir de aquí creamos la tabla
		?>
		<tr>
			<td colspan="8">
				<table id="editables-<?php echo $id; ?>" class="tabla-editables" style="display: none;">
					<tr>
						<td class="cabecera" colspan="2">
							CAMPOS EDITABLES
						</td>
					</tr>
					<tr>
						<td>
							<p class="campo">Slug: <input type="text" name="slug" value="<?php echo $slug; ?>"></p>
							<p class="campo">Texto Alt: <input type="text" name="texto_alt" value="<?php echo $texto_alt; ?>"></p>
							<p class="campo">Leyenda: <input type="text" name="leyenda" value="<?php echo $leyenda; ?>"></p>
							<p class="campo">Autor: <input type="text" name="autor" value="<?php echo $nombre_autor; ?>"></p>
						</td>
						<td>
							Descripción:<br><textarea name="descripcion"><?php echo $descripcion; ?></textarea><br>
							<?php
							if ( $permitir_comentarios == 'open' ) {
								?>
								Permitir comentarios: <input type="checkbox" name="permitir_comentarios" value="open" checked>
								<?php
							} else {
								?>
								Permitir comentarios: <input type="checkbox" name="permitir_comentarios" value="open">
								<?php
							}
							if ( $permitir_pingbacks == 'open' ) {
								?>
								Permitir pingbacks: <input type="checkbox" name="permitir_pingbacks" value="open" checked>
								<?php
							} else {
								?>
								Permitir pingbacks: <input type="checkbox" name="permitir_pingbacks" value="open">
								<?php
							}
							?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<?php
		// Como final del attachment, nos quedan el resto de datos del attachment y los metadatos de la imagen
		// Los volcaremos directamente al crear la tabla
		$metadatos_imagen = $stmpujante_metadatos[$id]['image_meta'];
		?>
		<tr>
			<td colspan="8">
				<table id="avanzados-<?php echo $id; ?>" class="tabla-avanzados" style="display:none;">
					<tr class="cabecera">
						<td colspan="4" class="izquierda derecha">Resto datos attachment</td>
						<td colspan="3" class="izquierda derecha">Metadatos de la imagen</td>
					</tr>
					<tr>
						<td class="izquierda">
							post_date: <?php echo $elemento -> post_date; ?><br>
							post_date_gmt: <?php echo $elemento -> post_date_gmt; ?><br>
							post_status: <?php echo $elemento -> post_status; ?><br>
							post_password: <?php echo $elemento -> post_password; ?>
						</td>
						<td>
							to_ping: <?php echo $elemento -> to_ping; ?><br>
							pinged: <?php echo $elemento -> pinged; ?><br>
							post_modified: <?php echo $elemento -> post_modified; ?><br>
							post_modified_gmt: <?php echo $elemento -> post_modified_gmt; ?>
						</td>
						<td>
							post_content_filtered: <?php echo $elemento -> post_content_filtered; ?><br>
							post_parent: <?php echo $elemento -> post_parent; ?><br>
							menu_order: <?php echo $elemento -> menu_order; ?><br>
							post_type: <?php echo $elemento -> post_type; ?>
						</td>
						<td class="derecha">
							post_mime_type: <?php echo $elemento -> post_mime_type; ?><br>
							comment_count: <?php echo $elemento -> comment_count; ?><br>
							filter: <?php echo $elemento -> filter; ?>
						</td>
						<td class="izquierda">
							aperture: <?php echo $metadatos_imagen['aperture']; ?><br>
							credit: <?php echo $metadatos_imagen['credit']; ?><br>
							camera: <?php echo $metadatos_imagen['camera']; ?><br>
							caption: <?php echo $metadatos_imagen['caption']; ?>
						</td>
						<td>
							created_timestamp: <?php echo $metadatos_imagen['created_timestamp']; ?><br>
							copyright: <?php echo $metadatos_imagen['copyright']; ?><br>
							focal_length: <?php echo $metadatos_imagen['focal_length']; ?><br>
							iso: <?php echo $metadatos_imagen['iso']; ?>
						</td>
						<td class="derecha">
							shutter_speed: <?php echo $metadatos_imagen['shutter_speed']; ?><br>
							title: <?php echo $metadatos_imagen['title']; ?><br>
							orientation: <?php echo $metadatos_imagen['orientation']; ?><br>
							keywords: <?php echo $metadatos_imagen['keywords']; ?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
		<?php
	}

	?>

	</table>
	<?php
	// Finalmente, vamos a crear una tabla con aquellos archivos de uploads que no tienen vinculación alguna
	?>
	<table class="archivos-huerfanos">
		<tr>
			<td colspan="2">
				Archivos huérfanos
			</td>
		</tr>
		<?php
		$contador = 0;
		foreach ( $subidas as $subida ) {
			if ( $subida['vinculado'] == 'no' ) {
				$contador++;
				?>
				<tr>
					<td>
						<?php echo $subida['ruta']; ?>
					</td>
					<td>
						<?php echo $subida['fichero']; ?>
					</td>
				</tr>
				<?php
			}
		}
		if ( $contador == 0 ) {
			?>
			<tr>
				<td colspan="2">
					No existen archivos huérfanos
				</td>
			</tr>
			<?php
		} else {
			?>
			<tr>
				<td colspan="2">
					<?php echo 'Total: ' . $contador . ' archivos huérfanos.'; ?>
				</td>
			</tr>
			<?php
		}
		?>
	</table>
	<script>
		function funcionVisualizarFormatos($id) {
			if ( document.getElementById('formatos-'+$id).style.display == 'none' ) {
				document.getElementById('formatos-'+$id).style.display = 'table';
				document.getElementById('vinculos-'+$id).style.display = 'table';
			} else {
				document.getElementById('formatos-'+$id).style.display = 'none';
				document.getElementById('vinculos-'+$id).style.display = 'none';
			}
		}
	
		function funcionVisualizarEditables($id) {
			if ( document.getElementById('editables-'+$id).style.display == 'none' ) {
				document.getElementById('editables-'+$id).style.display = 'table';
			} else {
				document.getElementById('editables-'+$id).style.display = 'none';
			}
		}
	
		function funcionVisualizarAvanzadas($id) {
			if ( document.getElementById('avanzados-'+$id).style.display == 'none' ) {
				document.getElementById('avanzados-'+$id).style.display = 'table';
			} else {
				document.getElementById('avanzados-'+$id).style.display = 'none';
			}
		}
	</script>

	<?php
}