////////////////////////////////////////////////////////
// 2.4.7. FUNCIONES JQUERY AJAX                       //
//        Función stmpujanteAjaxOperacionCarpeta()    //
//        Función stmpujanteAjaxOperacionAttachment() //
////////////////////////////////////////////////////////

function stmpujanteAjaxOperacionCarpeta( operacion ) {

	var this2=this;
	
	// Extraemos el valor del input, si existe
	nombre = '';
	if ( operacion == 'nueva-carpeta' && jQuery('#nuevo-nombre').val() ) { 
		nombre = jQuery('#nuevo-nombre').val();
	}
	
	if ( operacion == 'editar-carpeta' && jQuery('#editar-nombre').val() ) {
		nombre = jQuery('#editar-nombre').val();
	}
	destino = '';
	if ( operacion == 'mover-carpeta' && jQuery('#mover-seleccion').val() ) {
		destino = jQuery('#mover-seleccion').val();
	}
	if ( operacion == 'copiar-carpeta' && jQuery('#copiar-seleccion').val() ) {
		destino = jQuery('#copiar-seleccion').val();
	}
	
	// Buscamos el estado actual de las carpetas en pantalla
	var matrizCarpetas = new Array();
	jQuery(".truco").each(function(i) {
		
		carpeta = jQuery( this ).html();
		carpetas = carpeta.split(",");
		ident = '#apertura-'+carpetas[0];
		matrizCarpetas[i] = [ carpetas[0], carpetas[1], jQuery(ident).attr('class') ];
		
	});
	
	// Hacemos el evento AJAX
	jQuery.post( stmpujante_ajax.ajax_url, {
		
		_ajax_nonce: stmpujante_ajax.nonce,
		action: "operacion_carpeta",
		operacion: operacion,
		foco: jQuery('#focalizada').html(),
		seleccion: jQuery('#seleccionadas').html(),
		carpeta: nombre,
		destino: destino,
		estado: matrizCarpetas
	}, function( data ) {

		jQuery('#arbol_directorios').html(data.split('||')[0]);
		jQuery('#focalizada').html(data.split('||')[1]);
		jQuery('#seleccionadas').html(data.split('||')[2]);
		jQuery('#breadcrumb').html( data.split( '||' )[3]);
		
		jQuery('#'+operacion).hide();
		jQuery("select#operacion-carpetas").val('none');
		
	});
	
}

function stmpujanteAjaxOperacionAttachment( operacion ) {
	
	var this2 = this;
	
	// Extraemos el valor del input, si existe
	destino = '';
	if ( operacion == 'mover-attachment' && jQuery('#mover-seleccion-attachment').val() ) {
		destino = jQuery('#mover-seleccion-attachment').val();
	}
	if ( operacion == 'copiar-attachment' && jQuery('#copiar-seleccion-attachment').val() ) {
		destino = jQuery('#copiar-seleccion-attachment').val();
	}
	
	// Buscamos el estado actual de las carpetas en pantalla (no sé si hace falta)
	
	// Hacemos el evento AJAX
	jQuery.post( stmpujante_ajax.ajax_url, {
		
		_ajax_nonce: stmpujante_ajax.nonce,
		action: "operacion_attachment",
		operacion: operacion,
		seleccion: jQuery('#select_attach').html(),
		destino: destino,
		foco: jQuery('#focalizada').html(),
		
	}, function( data ) {

		jQuery( '#contenido_carpeta').html( data.split( '||' )[0] );
		jQuery( '#cantidad').html( data.split( '||' )[1] );
		jQuery( '#breadcrumb').html( data.split( '||' )[2] );
		
		jQuery( '#'+operacion ).hide();
		jQuery( "select#operacion-attachments" ).val( 'none' );
		jQuery( '#select_attach' ).html('');
		jQuery( '#seleccionados' ).html(0);
		
	});
	
}