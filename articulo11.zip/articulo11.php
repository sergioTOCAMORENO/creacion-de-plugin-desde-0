<?php

/*
Plugin Name: Arbol de directorios ( + AJAX )
Plugin URI: sergiotoca.com
Description: Plugin 11 de la serie de artículos 'Crear un plugin desde 0'. Muestra los terms de la taxonomía como directorios y subdirectorios. Añadimos AJAX
Version: 0.1
Author: Sergio TOCA MORENO
Author URI: sergiotoca.com
Text Domain: stmpujante
Domain Path: /idiomas
*/

//////////////////////////////////////////////////////////////////////
//                              INDICE                              //
// 1. Añadir taxonomía 'stmpujante_txn'                             //
// 2. Crear página de submenú                                       //
//    2.1. Página                                                   //
//    2.2. Ventanas modales                                         //
//    2.3. Estilos CSS                                              //
//    2.4. Funciones JavaScript                                     //
//         2.4.1. Función stmpujanteToggleApertura()                //
//         2.4.2. Función stmpujanteToggleSeleccion()               //
//         2.4.3. Función stmpujanteToggleFoco()                    //
//         2.4.4. Función stmpujanteOperacionesCarpeta()            //
//         2.4.5. Función stmpujanteOperacionesSelect()             //
// 3. Función stmpujante_funcion_recursiva_carpetas( $nivel, $id )  //
// 4. Función stmpujante_funcion_mostrar_carpetas( $nivel, $padre ) //
// 5. Función stmpujante_funcion_operaciones_carpetas()             //
// 6. Funciones AJAX                                                //
//    6.1. Función de enqueue de los scripts de AJAX                //
//    6.2. Función de recepción de datos y devolución de resultados //
//////////////////////////////////////////////////////////////////////

/////////////////////////////////////////
// 1. AÑADIR TAXONOMIA 'stmpujante_txn //
/////////////////////////////////////////
add_action( 'init', 'stmpujante_crear_directorios', 0 );

function stmpujante_crear_directorios() {
	
	// Primero, definimos las etiquetas que veremos en pantalla
	$etiquetas = array(
	
		'name'			=> _x( 'Directorios', 'taxonomy general name' ),
		'singular_name'	=> _x( 'Directorio', 'taxonomy singular name' ),
		'search_items'	=> __( 'Buscar por directorio', 'stmpujante' ),
		'all_items'		=> __( 'Todos los directorios', 'stmpujante' ),
		'parent_item'	=> __( 'Directorio superior', 'stmpujante' ),
		'parent_item_colon'	=> __( 'Directorio superior', 'stmpujante' ),
		'edit_item' 		=> __( 'Editar directorio', 'stmpujante' ),
		'update_item'		=> __( 'Actualizar directorio', 'stmpujante' ),
		'add_new_item'		=> __( 'Añadir nuevo directorio', 'stmpujante' ),
		'new_item_name'		=> __( 'Nombre del nuevo directorio', 'stmpujante' ),
		'menu_name'			=> __( 'Directorios', 'stmpujante' ),
		
	);
	
	// Después, los argumentos
	$argumentos = array(
	
		'hierarchical'		=> true,
		'labels'			=> $etiquetas,
		'show_ui'			=> true,
		'show_admin_column'	=> true,
		'query_var'			=> true,
		'rewrite'			=> array( 'slug' => 'directorio' ),
		
	);
	
	// Finalmente, declaramos la taxonomía
	register_taxonomy ( 'stmpujante_txn', array( 'attachment' ), $argumentos );
	
}

////////////////////////////////
// 2. CREAR PAGINA DE SUBMENU //
////////////////////////////////
add_action( 'admin_menu', 'stmpujante_funcion_crear_submenu' );

function stmpujante_funcion_crear_submenu() {

	add_submenu_page( 'upload.php', __( 'Sistema de gestión de medios', 'stmpujante' ), __( 'STMPujante', 'stmpujante'), 'manage_options', 'menu_stmpujante', 'stmpujante_funcion_crear_pagina' );
	
}

function stmpujante_funcion_crear_pagina() {

	
	// NOTA: El código que viene a continuación será llamado mediante AJAX en el próximo artículo

	// Primero, las matrices necesarias
	global $stmpujante_carpetas;
	
	// El primer valor de la matriz $stmpujante_carpetas es 'uploads'
	$stmpujante_carpetas[] = array ( 
		'id' 			=> 0, 
		'nombre' 		=> 'uploads', 
		'nivel' 		=> 0, 
		'abierta' 		=> 1, 
		'seleccionada' 	=> 0, 
		'padre' 		=> 0,
		'hijos'			=> stmpujante_funcion_recursiva_carpetas( 1, 0 ) // La función recursiva nos devuelve si un elemento tiene hijos
	);
	
////////////////////////////////
// 2. CREAR PAGINA DE SUBMENU //
//    2.1. Página             //
////////////////////////////////
	
	?>
	<h1><?php echo __( 'Sistema de directorios', 'stmpujante' ); ?></h1>
	<table width="100%">
		<tr>
			<td width="33%"><strong><?php echo __( 'Arbol de directorios', 'stmpujante' ); ?></strong></td>
			<td width="66%"><strong><?php echo __( 'Elementos del directorio seleccionado', 'stmpujante' ); ?></strong></td>
		</tr>
		<tr>
			<td id="arbol_directorios">
				<?php
				$cadena = stmpujante_funcion_mostrar_carpetas( 0, 0, '',0 );
				echo $cadena;
				?>
			</td>
			<td id="contenido_carpeta">
				<?php
				// NOTA: Aquí irá el contenido de la carpeta seleccionada
				?>
			</td>
		</tr>
		<tr>
			<td>
				<table>
					<tr>
						<td id="focalizada" style="display:none;">0</td>
						<td id="seleccionadas" style="display:none;"></td>
						<td>
							<?php
							stmpujante_funcion_operaciones_carpetas();
							?>
						</td>
					</tr>
				</table>
			<td>
				<?php
				// NOTA: Aquí irán las diferentes operaciones a realizar con el contenido
				?>
			</td>
		</tr>
	</table>
	<?php
	////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU //
	//    2.2. Ventanas modales   //
	////////////////////////////////

	// La página básica ya está. A partir de aquí vamos a crear la ventanas modales
	// Las ventanas modales emergerán en forma lightbox y en ellas estarán los campos con
	// los datos necesarios para la llamada AJAX a la función correspondiente.
	// Por tanto, las ventanas modales se tienen que crear con 'display:none'.
	?>
	<div id="nueva-carpeta" style="display:none">
	
		<h1><?php echo __( 'Crear nueva carpeta', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir nombre', 'stmpujante' ) . ': '; ?></label>
		<input id="nuevo-nombre" type="text"></input><br>
		<p id="aviso" style="color:red;font-weigt:bold;"></p>
		<div id="opciones">
			<button value="nueva" onclick="stmpujanteAjaxOperacionCarpeta('nueva-carpeta')"><?php echo __( 'Crear', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('nueva-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
		
	</div>
	
	<div id="editar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Editar nombre carpeta', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir nombre', 'stmpujante' ) . ': '; ?></label>
		<input id="editar-nombre" type="text"></input><br>
		<p id="aviso" style="color:red;font-weigt:bold;"></p>
		<div id="opciones">
			<button value="editar" onclick="stmpujanteAjaxOperacionCarpeta('editar-carpeta')"><?php echo __( 'Editar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('editar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="mover-carpeta" style="display:none">
	
		<h1><?php echo __( 'Mover carpeta/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="mover-seleccion"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="mover-recordatorio"></p>
		<div id="opciones">
			<button value="mover" onclick="stmpujanteAjaxOperacionCarpeta('mover-carpeta')"><?php echo __( 'Mover', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('mover-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="copiar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Copiar carpeta/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="copiar-seleccion"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="copiar-recordatorio"></p>
		<div id="opciones">
			<button value="copiar" onclick="stmpujanteAjaxOperacionCarpeta('copiar-carpeta')"><?php echo __( 'Copiar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('copiar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
		
	</div>
	
	<div id="eliminar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Eliminar carpeta/s', 'stmpujante' ); ?></h1>
		<p id="eliminar-recordatorio"></p>
		<div id="opciones">
			<button value="eliminar" onclick="stmpujanteAjaxOperacionCarpeta('eliminar-carpeta')"><?php echo __( 'Eliminar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('eliminar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="fondo"></div>
	
	<?php

	////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU //
	//    2.3. Estilos CSS        //
	////////////////////////////////

	?>
	<style>
		.subcarpeta {
			width: 16px;
		}
		.no-subcarpetas {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/vacio.gif'; ?>');
			background-repeat: no-repeat;
		}
		.abierta {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/reducir.gif'; ?>');
			background-repeat: no-repeat;
		}
		.cerrada {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/ampliar.gif'; ?>');
			background-repeat: no-repeat;
		}
		.carpeta-abierta {
			font-weight:bold;
		}
		.icono-abierta {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/abierta.gif'; ?>');
			background-repeat: no-repeat;
		}
		.icono-cerrada {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/cerrada.gif'; ?>');
			background-repeat: no-repeat;
		}
	</style>
	<?php

	//////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU   //
	//    2.4. Funciones JavaScript //
	//////////////////////////////////

	?>
	<script>
	
		///////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                        //
		//    2.4. Funciones JavaScript                      //
		//         2.4.1. Función stmpujanteToggleApertura() //
		///////////////////////////////////////////////////////

		// Con la función stmpujanteToggleApertura() controlamos la visualización de las subcarpetas de la carpeta actual
		// Además, cambiaremos la clase del control para que nos aparezca el icono + o -
		function stmpujanteToggleApertura(id) {

			elemento = document.getElementById('apertura-'+id);
		
			// Primero, comprobamos si tiene subcarpetas.
			if ( elemento.className == 'cerrada' ){
				
				// Eliminamos la clase 'cerrada' y la cambiamos por 'abierta'
				elemento.className = 'abierta';
				
				// Y visualizamos sus hijas
				document.getElementById('hijas-de-'+id).style.display = "table-row";
				
			} else {
				if ( elemento.className == 'abierta' ) {
					
					// Cambiamos clase 'abierta' por 'cerrada'
					elemento.className = 'cerrada';
					
					// Y ocultamos a las hijas
					document.getElementById('hijas-de-'+id).style.display = "none";
				}
			} // El tercer caso sería 'no-subcarpetas' y no hacemos nada
		}

		////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                         //
		//    2.4. Funciones JavaScript                       //
		//         2.4.2. Función stmpujanteToggleSeleccion() //
		////////////////////////////////////////////////////////
		
		// La función stmpujanteToggleSeleccion() nos permite tener un listado de todas las carpetas que están seleccionadas
		// Esto nos permitirá las acciones grupales
		function stmpujanteToggleSeleccion( id ) {
		
			// Cojemos el contenido de 'seleccionadas' y lo pasamos a una matriz
			lista = document.getElementById('seleccionadas').innerHTML;
			matriz = lista.split(",");
			
			// Ahora recorremos toda la matriz, para ver si está la carpeta seleccionada previamente
			var seleccionada=-1;
			for( contador=0; contador<matriz.length; contador++ ) {
				if ( parseInt( matriz[contador] ) == id ) {
					seleccionada = contador;
				}
			}
			
			// Si ya estaba seleccionada, la eliminamos
			if ( seleccionada != -1 ) {
				matriz.splice( seleccionada, 1); // Con delete matriz[seleccionada] se mantiene el elemento vacío
			} else { // Si no estaba seleccionada, la añadimos
				matriz.push(id.toString());
			}
			
			// Volvemos a convertir la matriz en cadena y la actualizamos en 'seleccionadas'
			if ( matriz.length > 0 ) {
				lista = matriz.toString();
			} else {
				lista = '';
			}
			if ( lista.charAt(0) == ',' ) {
				lista = lista.substring( 1, lista.length );
			}
			document.getElementById('seleccionadas').innerHTML = lista;
			
			// Finalmente, si existen seleccionadas, desactivamos 'nueva' y 'editar' de la lista de opciones
			opciones = document.getElementById('operacion-carpetas').getElementsByTagName("option");
			matriz = lista.split(",");
			if ( matriz.length > 1 ) {
				opciones[1].disabled = true;
				opciones[2].disabled = true;
			} else {
				opciones[1].disabled = false;
				opciones[2].disabled = false;
			}
			
		}

		///////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                    //
		//    2.4. Funciones JavaScript                  //
		//         2.4.3. Función stmpujanteToggleFoco() //
		///////////////////////////////////////////////////
		
		// La función stmpujanteToggleFoco() nos ayuda a determinar en qué carpeta se encuentra el foco, para las operaciones
		// Además, nos togglea el grosor del nombre de la carpeta y el icono de carpeta abierta o cerrada
		function stmpujanteToggleFoco(id) {
			
			// La div 'focalizada' contiene el $id de la carpeta con el foco. Lo cambiamos, guardando la anterior
			foco = document.getElementById('focalizada');
			carpetaAntigua = foco.innerHTML;
			foco.innerHTML = id;

			// Ahora, quitamos las características a la carpeta anterior
			if ( document.getElementById('nombre-'+carpetaAntigua).className == "carpeta-cerrada" ) {
				document.getElementById('nombre-'+carpetaAntigua).className = "carpeta-abierta";
			} else {
				document.getElementById('nombre-'+carpetaAntigua).className = "carpeta-cerrada";
			}
			if ( document.getElementById('icono-'+carpetaAntigua).className == "icono-cerrada" ) {
				document.getElementById('icono-'+carpetaAntigua).className = 'icono-abierta';
			} else {
				document.getElementById('icono-'+carpetaAntigua).className = 'icono-cerrada';
			}
			
			// Y hacemos lo propio con la nueva carpeta focalizada
			if ( document.getElementById('nombre-'+id).className == 'carpeta-cerrada' ) {
				document.getElementById('nombre-'+id).className = 'carpeta-abierta';
			} else {
				document.getElementById('nombre-'+id).className = 'carpeta-cerrada';
			}
			if ( document.getElementById('icono-'+id).className == 'icono-abierta' ) {
				document.getElementById('icono-'+id).className = 'icono-cerrada';
			} else {
				document.getElementById('icono-'+id).className = 'icono-abierta';
			}
		
		}

		/////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                          //
		//    2.4. Funciones JavaScript                        //
		//         2.4.4. Función stmpujanteOperacionCarpeta() //
		/////////////////////////////////////////////////////////
		
		// La función stmpujanteOperacionCarpeta() nos realiza diversos cometidos:
		// - Primero, controla si la operación sera individual o grupal
		// - Segundo, incluye los comentarios necesarios para que el usuario esté totalmente informado
		// - Finalmente, visualiza la ventana de la operación seleccionada
		function stmpujanteOperacionCarpeta() {
			
			// Averiguamos si será una operación grupal o individual
			lista = document.getElementById('seleccionadas').innerHTML;
			if ( lista == '' ) {
				grupal = false;
			} else {
				grupal = true;
			}
			// Vemos qué operación se ha seleccionado
			operacion = document.getElementById('operacion-carpetas').value;
			
			// Incluimos los comentarios necesarios para informar al usuario
			switch( operacion ) {
				case 'nueva': // Sólo vaciamos el input
					document.getElementById('nuevo-nombre').value = '';
					break;
				case 'editar': // Introducimos en el input el nombre previo de la carpeta
					if ( grupal == false ) {
						carpeta = document.getElementById('focalizada').innerHTML;
					} else {
						matriz = lista.split(",");
						carpeta = matriz[0];
					}
					nombre = document.getElementById('nombre-'+carpeta).innerHTML;
					document.getElementById('editar-nombre').value = nombre;
					break;
				case 'mover': // Indicamos qué carpeta/s va/n a ser movida/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a mover la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a mover las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('mover-recordatorio').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'mover-seleccion' );
					break;
				case 'copiar': // Indicamos qué carpeta/s va/n a ser copiada/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a copiar la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a copiar las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('copiar-recordatorio').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'copiar-seleccion' );
					break;
				case 'eliminar': // Indicamos qué carpeta/s va/n a ser borrada/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a borrar la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a borrar las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('eliminar-recordatorio').innerHTML = cadena;
					break;
			}
			
			// Ahora, creamos las ventanas modales en forma lightbox
			if ( operacion != 'none' ) {
				ventana = document.getElementById( operacion + '-carpeta' );
				ventana.style.margin = '0 auto';
				ventana.style.marginTop = '100px';
				ventana.style.display = 'block';
			}
			
			// Finalmente, establecemos el foco
			switch ( operacion ) {
				case 'nueva':
					document.getElementById('nuevo-nombre').focus();
					break;
				case 'editar':
					document.getElementById('editar-nombre').focus();
					break;
				case 'mover':
					document.getElementById('mover-seleccion').focus();
					break;
				case 'copiar':
					document.getElementById('copiar-seleccion').focus();
					break;
				case 'eliminar':
					// En este caso no establecemos foco
					break;
			}
		
		}

		///////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                        //
		//    2.4. Funciones JavaScript                      //
		//         2.4.5. Función stmpujanteOpcionesSelect() //
		///////////////////////////////////////////////////////
		
		// La función stmpujanteOpcionesSelect nos creará las opciones de los campos select
		function stmpujanteOpcionesSelect( id ) {
			
			// Primero creamos una matriz con todas las carpetas, gracias al campo 'truco'
			matriz = document.getElementsByClassName('truco');
			var matrizCarpetas = new Array( matriz.length );
			if ( matrizCarpetas > 0 ) {
				matrizCarpetas.splice( 0, matrizCarpetas.length );
			}
			for ( i = 0; i < matriz.length; i++ ) {
				carpeta = matriz[i].innerHTML;
				carpetas = carpeta.split(",");
				matrizCarpetas[i] = [ carpetas[0], carpetas[1] ];
			}
			
			// Averiguamos si será una operación grupal o individual
			lista = document.getElementById('seleccionadas').innerHTML;
			if ( lista == '' ) {
				grupal = false;
			} else {
				grupal = true;
			}

			// Ahora debemos descartar la/s carpeta/s que no corresponda/n
			if ( grupal == false ) {
				actual = document.getElementById('focalizada').innerHTML;
				indice = -1
				for ( i = 0; i < matrizCarpetas.length; i++ ) {
					if ( matrizCarpetas[i][0] == actual ) {
						indice = i;
					}
				}
				if ( indice != -1 ) {
					matrizCarpetas.splice(indice,1);
				}
			} else {
				matrizSeleccionadas = lista.split(",");
				for ( i = 0; i < matrizSeleccionadas.length; i++ ) {
					for ( j = 0; j < matrizCarpetas.length; j++ ) {
						if ( matrizSeleccionadas[i] == matrizCarpetas[j][0] ) {
							matrizCarpetas.splice(j,1);
						}
					}
				}
			}
			
			// Finalmente, con la matrizCarpetas creamos las opciones
			select = document.getElementById( id );
			while ( select.hasChildNodes() ) {
				select.removeChild( select.childNodes[0] );
			}
			for ( i = 0; i < matrizCarpetas.length; i++ ) {
				opcion = document.createElement("option");
				opcion.value = matrizCarpetas[i][0];
				opcion.text = matrizCarpetas[i][1];
				select.appendChild(opcion);
			}
			
		}
		
		// La función stmpujanteOcultarOperacion simplemente oculta la ventana modal abierta
		function stmpujanteOcultarOperacion( id ) {
			
			ventana = document.getElementById( id );
			ventana.style.display = 'none';
			document.getElementById('operacion-carpetas').selectedIndex= 0;
			
			
		}
			
	</script>
	<?php
	
}

/////////////////////////////////////////////////////////////////////
// 3. FUNCION stmpujante_funcion_recursiva_carpetas( $nivel, $id ) //
// Descripción: Con los parámetros recibidos, busca los terms cuyo //
// padre sea $id y, por cada uno que encuentra, lo mete en la      //
// matriz $stmpujante_carpetas y se llama a si misma.              //
// Inicio creación: 11 / III / 17                                  //
// Finalización: 14 / III / 17                                     //
/////////////////////////////////////////////////////////////////////

function stmpujante_funcion_recursiva_carpetas( $nivel, $id ) {
	
	// Primero accedemos a la matriz $stmpujante_carpetas
	global $stmpujante_carpetas;
	// Y actualizamos el nivel
	$hijos = array();
	// Realizamos la consulta
	$hijos = get_terms( array( 
		'taxonomy' => 'stmpujante_txn', 
		'orderby' => 'name',
		'hide_empty' => 0,
		'parent' => $id 
	) );
	
	if ( count( $hijos ) != 0 ) {
		
		foreach ( $hijos as $hijo ) {
			
			// Por cada hijo encontrado del term, solicitado, realizamos un registro
			$stmpujante_carpetas[] = array(
			
				'id' 			=> $hijo->term_id,
				'nombre' 		=> $hijo->name,
				'nivel' 		=> $nivel,
				'abierta' 		=> 0,
				'seleccionada' 	=> 0,
				'padre' 		=> $id,
				'hijos'			=> stmpujante_funcion_recursiva_carpetas( $nivel+1, $hijo->term_id )
				
			);
			
		}
		
	}
	
	// Retorna la cantidad de hijos que tiene la carpeta
	return count( $hijos );
	
}

/////////////////////////////////////////////////////////
// 4. FUNCION stmpujante_funcion_mostrar_carpetas()    //
// Descripción: Crea el árbol de directorios, con      //
// HTML y JS incluidos.                                //
// Posteriormente he visto que mejor hacerla recursiva //
// Inicio creación: 11 / III / 17                      //
// Finalización: 14 / III / 17                         //
/////////////////////////////////////////////////////////

function stmpujante_funcion_mostrar_carpetas( $nivel, $padre, $estado = '', $foco = 0 ) {

	// Recuperamos la matriz ya llena $stmpujante_carpetas
	global $stmpujante_carpetas;
	/*foreach( $estado as $item ) {
		echo $item[0] . ' | ' . $item[1] . ' | ' . $item[2] . '<br>';
	}*/
	$cadena = '';
	// Recorremos la matriz $stmpujante_carpetas buscando las carpetas con el $nivel recibido
	foreach ( $stmpujante_carpetas as $carpeta ) {
		
		if ( $carpeta['nivel'] == $nivel && $carpeta['padre'] == $padre ) {
	
			$cadena .= '<table id="carpeta">';
			$cadena .= '<tr id="carpeta-' . $carpeta['id'] . '" style="height:16px;"><td><table><tr>';

			for ( $i = 1; $i < $nivel; $i++ ) {

				$cadena .='<td class="pasante" style="width:16px;"><td>';

			}
			if ( $nivel > 0 ) {

				$cadena .='<td class="subcarpeta" style="width:16px;"><td>';

			}

			$cadena .='<td class="truco" style="display:none;">' . $carpeta['id'] . ',' . $carpeta['nombre'] . '</td>';

			// Tenemos 4 parámetros: situación ( nueva/abierta/cerrada ), hijos ( sí/no ), uploads ( sí/no ), foco ( sí/no )
			// Esto crea 24 posibilidades
			// Si hemos hecho una operación, vemos cómo estaba antes
			$situacion = 'nueva';
			foreach ( $estado as $item ) {
				if ( $item[0] == $carpeta['id'] ) {
					$situacion = $item[2];
				}
			}
			
			// La apertura, depende de si tiene hijos o no, y en qué situación previa estaba
			if ( $carpeta['hijos'] == 0 ) {
				$clase = 'no-subcarpetas';
			} else {
				$clase = ( $situacion == 'abierta' ) ? 'abierta' : 'cerrada';
			}

			$cadena .='<td id="apertura-' . $carpeta['id'] . '" class="' . $clase . '" onclick="stmpujanteToggleApertura(' . $carpeta['id'] . ');" width="16px"></td>';

			// La selección sólo cambia si es uploads o no
			$seleccion = ( $carpeta['id'] == 0 ) ? ' disabled="true"' : '';
			$cadena .='<td id="seleccion" width="16px"><input type="checkbox" id="seleccion-' . $carpeta['id'] . '" onchange="stmpujanteToggleSeleccion(' . $carpeta['id'] . ');"' . $seleccion . '></td>';

			if ( $carpeta['id'] == $foco ) { // Si tiene el foco

				$cadena .='<td id="nombre-' . $carpeta['id'] . '" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ')" class="carpeta-abierta">' . $carpeta['nombre'] . '</td>';
				$cadena .='<td id="icono-' . $carpeta['id'] . '" class="icono-abierta" width="16px"></td>';

			} else {

				$cadena .='<td id="nombre-' . $carpeta['id'] . '" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ')" class="carpeta-cerrada">' . $carpeta['nombre'] . '</td>';
				$cadena .='<td id="icono-' . $carpeta['id'] . '" class="icono-cerrada" width="16px"></td>';

			}

			$cadena .='</tr></table></td></tr>';
			
			if ( $carpeta['hijos'] != 0 ) {
				
				if ( $clase == 'cerrada' ) {
					
					$cadena .='<tr id="hijas-de-' . $carpeta['id'] . '" style="display: none;">';
					
				} else {
					
					$cadena .='<tr id="hijas-de-' . $carpeta['id'] . '" style="display: table-row;">';
					
				}
				
				$cadena .='<td colspan="' . ( $nivel + 6 ) . '">';

				$cadena .= stmpujante_funcion_mostrar_carpetas( $nivel + 1, intval( $carpeta['id']), $estado, $foco );

				$cadena .= '</td></tr>';
				
			}
			
			$cadena .='</table>';

		}
		
	}
	
	return $cadena;
	
}

//////////////////////////////////////////////////////////
// 5. FUNCION stmpujante_funcion_operaciones_carpetas() //
// Descripción: Muestra el campo select con las         //
// diferentes acciones a realizar con las carpetas.     //
// Fecha creación: 11 / III / 17                        //
// Finalización: 14 / III / 17                          //
//////////////////////////////////////////////////////////

function stmpujante_funcion_operaciones_carpetas() {
	
	?>
	<label><?php echo __( 'Seleccione una operación', 'stmpujante' ) . ' :'; ?></label>
	<select id="operacion-carpetas" onchange="stmpujanteOperacionCarpeta();">
		<option value="none"><?php echo __( 'Seleccione', 'stmpujante' ) . '...'; ?></option>
		<option class="unica" value="nueva"><?php echo __( 'Nueva subcarpeta', 'stmpujante' ); ?></option>
		<option class="individual no-grupal" value="editar"><?php echo __( 'Editar nombre', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="mover"><?php echo __( 'Mover carpeta/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="copiar"><?php echo __( 'Copiar carpeta/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="eliminar"><?php echo __( 'Eliminar carpeta/s', 'stmpujante' ); ?></option>
	</select>
	<?php
	
}

////////////////////////////////////////////////////////////////////////
// 6. Funciones AJAX                                                  //
//    6.1. Función de enqueue de los scripts de AJAX                  //
//    6.2. Función de recepción de datos y devolución de resultados   //
//    6.3. Función stmpujante_mostrar_ajax_carpetas( $nivel, $padre ) //
// Fecha creación: 16 / III / 17                                      //
// Finalización: (prevista) 19 / III / 17                             //
////////////////////////////////////////////////////////////////////////

// Función para 'encolar' los scripts de AJAX
add_action( 'init', 'stmpujante_funcion_enqueue_scripts' );

function stmpujante_funcion_enqueue_scripts() {
	
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'ajax-script', plugin_dir_url(__FILE__) . 'js/mi_ajax.js' ); // Ahora creo que podemos prescindir de ella
	$title_nonce = wp_create_nonce( 'devolucion_resultado' );
	wp_localize_script( 'ajax-script', 'stmpujante_ajax', array(
	
		'ajax_url' 	=> admin_url('admin-ajax.php'),
		'nonce'		=> $title_nonce
		
	));
	
}

// Función que recibe los datos, los procesa y devuelve el resultado
add_action( 'wp_ajax_operacion_carpeta', 'stmpujante_funcion_modificacion_carpeta' );

function stmpujante_funcion_modificacion_carpeta() {
	
	// Comprobamos la coincidencia del nonce
	check_ajax_referer( 'devolucion_resultado' );
	
	// Extaemos los datos
	$operacion = $_POST['operacion'];
	$foco = $_POST['foco'];
	$seleccion = $_POST['seleccion'];
	$nombre = $_POST['carpeta'];
	$destino = $_POST['destino'];
	$estado = $_POST['estado'];
	
	switch ( $operacion ) {
		
		case 'nueva-carpeta':
			
			$args = array (
				'parent'	=> $foco
			);
			$matriz = wp_insert_term( $nombre, 'stmpujante_txn', $args );
			// Ahora modificamos el estado, para que el padre esté abierto
			foreach ( $estado as $item ) {
				if ( intval($item[0]) == intval($foco) ) {
					$estado[] = [ $item[0] , $item[1] , "abierta" ];
				}
			}
			// Actualizamos el foco
			$foco = $matriz['term_id'];
			break;
			
		case 'editar-carpeta':
			$args = array (
				'name'	=> $nombre
			);
			wp_update_term( $foco, 'stmpujante_txn', $args );
			break;
			
		case 'mover-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				$args = array (
					'parent'	=> $destino
				);
				wp_update_term( $foco, 'stmpujante_txn', $args );
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				break;
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					$args = array (
						'parent'	=> $destino
					);
					wp_update_term( $elemento, 'stmpujante_txn', $args );
				}
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}

				$seleccion = '';
				break;
				
			}
				
		case 'copiar-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				// Necesitamos saber el nombre de la carpeta con el foco
				foreach ( $estado as $item ) {
					if ( $item[0] ==  $foco ) {
						echo $item[1];
						$args = array (
							'parent'	=> $destino
						);
						wp_insert_term( $item[1], 'stmpujante_txn', $args );
					}
				}
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					foreach ( $estado as $item ) {
						if ( $item[0] == $elemento ) {
							$args = array (
								'parent'	=> $destino
							);
							wp_insert_term( $item[1], 'stmpujante_txn', $args );
						}
					}
				}
				$seleccion = '';
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				
			}
			break;
			
		case 'eliminar-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				wp_delete_term( $foco, 'stmpujante_txn' );
				$foco = 0;
				break;
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					wp_delete_term( $elemento, 'stmpujante_txn' );
					if ( $foco == $elemento ) {
						$foco = 0;
					}
				}
				$seleccion = '';
				break;
				
			}
	}

	// Ahora tenemos que volver a crear la matriz $stmpujante_carpetas
	//unset ( $GLOBALS['stmpujante_carpetas'] );
	global $stmpujante_carpetas;
	//$stmpujante_carpetas_dos = array();
	// El primer valor de la matriz $stmpujante_carpetas es 'uploads'
	$stmpujante_carpetas[] = array ( 
		'id' 			=> 0, 
		'nombre' 		=> 'uploads', 
		'nivel' 		=> 0, 
		'abierta' 		=> 1, 
		'seleccionada' 	=> 0, 
		'padre' 		=> 0,
		'hijos'			=> stmpujante_funcion_recursiva_carpetas( 1, 0 ) // La función recursiva nos devuelve si un elemento tiene hijos
	);
	
	// Ahora, creamos la $cadena
	$cadena = stmpujante_funcion_mostrar_carpetas( 0, 0, $estado, $foco );

	// Devolvemos los resultados
	$resultado = '';
	$resultado .= $cadena . '||';
	$resultado .= $foco . '||';
	$resultado .= $seleccion;
	
	echo $resultado;
	
	// Finalizamos el evento AJAX
	wp_die();
	
}

?>