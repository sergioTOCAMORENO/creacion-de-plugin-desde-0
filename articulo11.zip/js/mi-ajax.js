		/////////////////////////////////////////////////////
		// FUNCION JQUERY AJAX                             //
		// 2.4.6. Función stmpujanteAjaxOperacionCarpeta() //
		/////////////////////////////////////////////////////
		
		function stmpujanteAjaxOperacionCarpeta( operacion ) {
			
			console.log('hola');
			
			var this2=this;
			jQuery.post( stmpujante_ajax.ajax_url, {
				
				_ajax_nonce: stmpujante_ajax.nonce,
				action: "operacion_carpeta",
				operacion: operacion,
				foco: jQuery('#focalizada').html(),
				seleccion: jQuery('#seleccionadas').html()
				// falta matrizCarpetas
			}, function( data ) {
				
				jQuery('#arbol_directorios').html(data);
				
			});
			
		}
