/////////////////////////////////////////////////////
// FUNCION JQUERY AJAX                             //
// 2.4.6. Función stmpujanteAjaxOperacionCarpeta() //
/////////////////////////////////////////////////////

function stmpujanteAjaxOperacionCarpeta( operacion ) {

	var this2=this;
	
	// Extraemos el valor del input, si existe
	nombre = '';
	if ( operacion == 'nueva-carpeta' && jQuery('#nuevo-nombre').val() ) { 
		nombre = jQuery('#nuevo-nombre').val();
	}
	
	if ( operacion == 'editar-carpeta' && jQuery('#editar-nombre').val() ) {
		nombre = jQuery('#editar-nombre').val();
	}
	destino = '';
	if ( operacion == 'mover-carpeta' && jQuery('#mover-seleccion').val() ) {
		destino = jQuery('#mover-seleccion').val();
	}
	if ( operacion == 'copiar-carpeta' && jQuery('#copiar-seleccion').val() ) {
		destino = jQuery('#copiar-seleccion').val();
	}
	
	// Buscamos el estado actual de las carpetas en pantalla
	var matrizCarpetas = new Array();
	jQuery(".truco").each(function(i) {
		
		carpeta = jQuery( this ).html();
		carpetas = carpeta.split(",");
		ident = '#apertura-'+carpetas[0];
		matrizCarpetas[i] = [ carpetas[0], carpetas[1], jQuery(ident).attr('class') ];
		
	});
	
	// Hacemos el evento AJAX
	jQuery.post( stmpujante_ajax.ajax_url, {
		
		_ajax_nonce: stmpujante_ajax.nonce,
		action: "operacion_carpeta",
		operacion: operacion,
		foco: jQuery('#focalizada').html(),
		seleccion: jQuery('#seleccionadas').html(),
		carpeta: nombre,
		destino: destino,
		estado: matrizCarpetas
	}, function( data ) {

		jQuery('#arbol_directorios').html(data.split('||')[0]);
		jQuery('#focalizada').html(data.split('||')[1]);
		jQuery('#seleccionadas').html(data.split('||')[2]);
		
		jQuery('#'+operacion).hide();
		jQuery("select#operacion-carpetas").val('none');
		
	});
	
}