<?php

/*
Plugin Name: CREAR TAXONOMIA DIRECTORIO
Plugin URI: sergiotoca.com
Description: Plugin 4 de la serie de artículos 'Crear un plugin desde 0'. Crea la taxonomía directorio
Version: 0.1
Author: Sergio TOCA MORENO
Author URI: sergiotoca.com
Text Domain: stmpili
Domain Path: /idiomas
*/

add_action( 'after_setup_theme', 'copia_plantilla_tema' );
	
function copia_plantilla_tema() {
		
	$plantilla = 'articulo03-template.php';
	$direccionTema = str_replace( '\\', '\/', urldecode( get_template_directory() ) );
		
	if ( file_exists( $direccionTema . '/' . $plantilla ) ) {
			
		return;
			
	} else {
			
		$direccionOrigen = str_replace( '\\', '\/', urldecode( plugin_dir_path( __FILE__ ) ) );
		copy( $direccionOrigen . $plantilla, $direccionTema . '/' . $plantilla );
	}
	
}

// Añadir taxonomía directorios

add_action( 'init', 'stmpujante_crear_directorios', 0 );

function stmpujante_crear_directorios() {
	
	// Primero, definimos las etiquetas que veremos en pantalla
	$etiquetas = array(
	
		'name'			=> _x( 'Directorios', 'taxonomy general name' ),
		'singular_name'	=> _x( 'Directorio', 'taxonomy singular name' ),
		'search_items'	=> __( 'Buscar por directorio', 'stmpujante' ),
		'all_items'		=> __( 'Todos los directorios', 'stmpujante' ),
		'parent_item'	=> __( 'Directorio superior', 'stmpujante' ),
		'parent_item_colon'	=> __( 'Directorio superior', 'stmpujante' ),
		'edit_item' 		=> __( 'Editar directorio', 'stmpujante' ),
		'update_item'		=> __( 'Actualizar directorio', 'stmpujante' ),
		'add_new_item'		=> __( 'Añadir nuevo directorio', 'stmpujante' ),
		'new_item_name'		=> __( 'Nombre del nuevo directorio', 'stmpujante' ),
		'menu_name'			=> __( 'Directorios', 'stmpujante' ),
		
	);
	
	// Después, los argumentos
	$argumentos = array(
	
		'hierarchical'		=> true,
		'labels'			=> $etiquetas,
		'show_ui'			=> true,
		'show_admin_column'	=> true,
		'query_var'			=> true,
		'rewrite'			=> array( 'slug' => 'directorio' ),
		
	);
	
	// Finalmente, declaramos la taxonomía
	register_taxonomy ( 'stmpujante_txn', array( 'attachment' ), $argumentos );
	
}

?>