<?php

/*
Plugin Name: Arbol de directorios y attachments
Plugin URI: sergiotoca.com
Description: Plugin 12 de la serie de artículos 'Crear un plugin desde 0'. Muestra los terms de la taxonomía y los attachments
Version: 0.1
Author: Sergio TOCA MORENO
Author URI: sergiotoca.com
Text Domain: stmpujante
Domain Path: /idiomas
*/

//////////////////////////////////////////////////////////////////////////////////
//                              INDICE                                          //
// 1. Añadir taxonomía 'stmpujante_txn'                                         //
// 2. Crear página de submenú                                                   //
//    2.1. Página                                                               //
//    2.2. Ventanas modales                                                     //
//    2.3. Estilos CSS                                                          //
//    2.4. Funciones JavaScript                                                 //
//         2.4.1. Función stmpujanteToggleApertura()                            //
//         2.4.2. Función stmpujanteToggleSeleccion()                           //
//         2.4.3. Función stmpujanteToggleFoco()                                //
//         2.4.4. Función stmpujanteOperacionesCarpeta()                        //
//         2.4.5. Función stmpujanteOperacionesSelect()                         //
//         2.4.6. Función stmpujanteOcultarOperacion()                          //
//         2.4.7. Funciones AJAX ( en archivo 'mi_ajax.js' )                    //
//                Función stmpujanteAjaxOperacionCarpeta()                      //
//                Función stmpujanteAjaxOperacionesAttachment()                 //
//         2.4.8. Función stmpujanteToggleSelectAttachment()                    //
//         2.4.9. Función stmpujanteOperacionAttachment()                       //
// 3. Función stmpujante_funcion_recursiva_carpetas( $nivel, $id )              //
// 4. Función stmpujante_funcion_mostrar_carpetas( $nivel, $padre )             //
// 5. Función stmpujante_funcion_operaciones_carpetas()                         //
// 6. Funciones AJAX                                                            //
//    6.1. Función de enqueue de los scripts de AJAX                            //
//    6.2. Función de recepción de datos y devolución de resultados carpetas    //
//    6.3. Función de recepción de datos y devolución de resultados attachments //
// 7. Función stmpujante_funcion_mostrar_attachments( $foco )                   //
// 8. Función stmpujante_funcion_operaciones_attachments()                      //
// 9. Función stmpujante_funcion_breadcrumb( $foco )                            //
//////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////
// 1. AÑADIR TAXONOMIA 'stmpujante_txn //
/////////////////////////////////////////
add_action( 'init', 'stmpujante_crear_directorios', 0 );

function stmpujante_crear_directorios() {
	
	// Primero, definimos las etiquetas que veremos en pantalla
	$etiquetas = array(
	
		'name'			=> _x( 'Directorios', 'taxonomy general name' ),
		'singular_name'	=> _x( 'Directorio', 'taxonomy singular name' ),
		'search_items'	=> __( 'Buscar por directorio', 'stmpujante' ),
		'all_items'		=> __( 'Todos los directorios', 'stmpujante' ),
		'parent_item'	=> __( 'Directorio superior', 'stmpujante' ),
		'parent_item_colon'	=> __( 'Directorio superior', 'stmpujante' ),
		'edit_item' 		=> __( 'Editar directorio', 'stmpujante' ),
		'update_item'		=> __( 'Actualizar directorio', 'stmpujante' ),
		'add_new_item'		=> __( 'Añadir nuevo directorio', 'stmpujante' ),
		'new_item_name'		=> __( 'Nombre del nuevo directorio', 'stmpujante' ),
		'menu_name'			=> __( 'Directorios', 'stmpujante' ),
		
	);
	
	// Después, los argumentos
	$argumentos = array(
	
		'hierarchical'		=> true,
		'labels'			=> $etiquetas,
		'show_ui'			=> true,
		'show_admin_column'	=> true,
		'query_var'			=> true,
		'rewrite'			=> array( 'slug' => 'directorio' ),
		
	);
	
	// Finalmente, declaramos la taxonomía
	register_taxonomy ( 'stmpujante_txn', array( 'attachment' ), $argumentos );
	
}

////////////////////////////////
// 2. CREAR PAGINA DE SUBMENU //
////////////////////////////////
add_action( 'admin_menu', 'stmpujante_funcion_crear_submenu' );

function stmpujante_funcion_crear_submenu() {

	add_submenu_page( 'upload.php', __( 'Sistema de gestión de medios', 'stmpujante' ), __( 'STMPujante', 'stmpujante'), 'manage_options', 'menu_stmpujante', 'stmpujante_funcion_crear_pagina' );
	
}

function stmpujante_funcion_crear_pagina() {

	
	// NOTA: El código que viene a continuación será llamado mediante AJAX en el próximo artículo

	// Primero, las matrices necesarias
	global $stmpujante_carpetas;
	
	// El primer valor de la matriz $stmpujante_carpetas es 'uploads'
	$stmpujante_carpetas[] = array ( 
		'id' 			=> 0, 
		'nombre' 		=> 'uploads', 
		'nivel' 		=> 0, 
		'abierta' 		=> 1, 
		'seleccionada' 	=> 0, 
		'padre' 		=> 0,
		'hijos'			=> stmpujante_funcion_recursiva_carpetas( 1, 0 ) // La función recursiva nos devuelve si un elemento tiene hijos
	);
	
////////////////////////////////
// 2. CREAR PAGINA DE SUBMENU //
//    2.1. Página             //
////////////////////////////////
	
	?>
	<h1><?php echo __( 'Sistema de directorios', 'stmpujante' ); ?></h1>
	<table width="100%" height="100%" style="min-height:100%">
		<tr>
			<td width="33%"><h2><?php echo __( 'Arbol de directorios', 'stmpujante' ); ?></h2></td>
			<td width="66%"><h2><?php echo __( 'Elementos del directorio seleccionado', 'stmpujante' ); ?></h2></td>
		</tr>
		<tr>
			<td style="vertical-align:top;" rowspan="2" height="600px">
				<div id="arbol_directorios" style="vertical-align:top; background:white; height:100%; border: #e5e5e5 inset;">
					<?php
					$cadena = stmpujante_funcion_mostrar_carpetas( 0, 0, '',0 );
					echo $cadena;
					?>
				</div>
			</td>
			<td id="breadcrumb" style="display:inline-flex;">
				<?php
				$cadena = stmpujante_funcion_breadcrumb(0);
				echo $cadena;
				?>
			</td>
		<tr>
			<td style="height:100%;">
				<div id="contenido_carpeta" style="vertical-align:top; background:white; max-height:100%; min-height:100%;border: #e5e5e5 inset;overflow: auto;">
					<?php
					$resultado = explode( '||', stmpujante_funcion_mostrar_attachments( 0 ) );
					echo $resultado[0];
					?>
				</div>
			</td>
		</tr>
		<tr>
			<td>
				<table>
					<tr>
						<td id="focalizada" style="display:none;">0</td>
						<td id="seleccionadas" style="display:none;"></td>
						<td>
							<?php
							stmpujante_funcion_operaciones_carpetas();
							?>
						</td>
					</tr>
				</table>
			<td>
				<table>
					<tr>
						<td id="select_attach" style="display:none;display:block;"></td>
						<td>
							<?php
							stmpujante_funcion_operaciones_attachments();
							echo __( 'Ficheros', 'stmpujante' ) . ': <spam id="cantidad">' . $resultado[1] . '</spam>';
							echo ' / ' . __( 'Seleccionados', 'stmpujante' ) . ': <spam id="seleccionados">0</spam></spam>';
							?>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
	<?php
	////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU //
	//    2.2. Ventanas modales   //
	////////////////////////////////

	// La página básica ya está. A partir de aquí vamos a crear la ventanas modales
	// Las ventanas modales emergerán en forma lightbox y en ellas estarán los campos con
	// los datos necesarios para la llamada AJAX a la función correspondiente.
	// Por tanto, las ventanas modales se tienen que crear con 'display:none'.
	?>
	<div id="nueva-carpeta" style="display:none">
	
		<h1><?php echo __( 'Crear nueva carpeta', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir nombre', 'stmpujante' ) . ': '; ?></label>
		<input id="nuevo-nombre" type="text"></input><br>
		<p id="aviso" style="color:red;font-weigt:bold;"></p>
		<div id="opciones">
			<button value="nueva" onclick="stmpujanteAjaxOperacionCarpeta('nueva-carpeta')"><?php echo __( 'Crear', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('nueva-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
		
	</div>
	
	<div id="editar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Editar nombre carpeta', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir nombre', 'stmpujante' ) . ': '; ?></label>
		<input id="editar-nombre" type="text"></input><br>
		<p id="aviso" style="color:red;font-weigt:bold;"></p>
		<div id="opciones">
			<button value="editar" onclick="stmpujanteAjaxOperacionCarpeta('editar-carpeta')"><?php echo __( 'Editar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('editar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="mover-carpeta" style="display:none">
	
		<h1><?php echo __( 'Mover carpeta/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="mover-seleccion"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="mover-recordatorio"></p>
		<div id="opciones">
			<button value="mover" onclick="stmpujanteAjaxOperacionCarpeta('mover-carpeta')"><?php echo __( 'Mover', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('mover-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="copiar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Copiar carpeta/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="copiar-seleccion"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="copiar-recordatorio"></p>
		<div id="opciones">
			<button value="copiar" onclick="stmpujanteAjaxOperacionCarpeta('copiar-carpeta')"><?php echo __( 'Copiar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('copiar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
		
	</div>
	
	<div id="eliminar-carpeta" style="display:none">
	
		<h1><?php echo __( 'Eliminar carpeta/s', 'stmpujante' ); ?></h1>
		<p id="eliminar-recordatorio"></p>
		<div id="opciones">
			<button value="eliminar" onclick="stmpujanteAjaxOperacionCarpeta('eliminar-carpeta')"><?php echo __( 'Eliminar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('eliminar-carpeta')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="mover-attachment" style="display:none">
	
		<h1><?php echo __( 'Mover attachment/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="mover-seleccion-attachment"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="mover-recordatorio-attachment"></p>
		<div id="opciones">
			<button value="mover" onclick="stmpujanteAjaxOperacionAttachment('mover-attachment')"><?php echo __( 'Mover', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('mover-attachment')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="copiar-attachment" style="display:none">
	
		<h1><?php echo __( 'Copiar attachment/s', 'stmpujante' ); ?></h1>
		<label><?php echo __( 'Introducir carpeta de destino', 'stmpujante' ) . ': '; ?></label>
		<select id="copiar-seleccion-attachment"></select>
		<p id="aviso" style="color:red;font-weight:bold;"></p>
		<p id="copiar-recordatorio-attachment"></p>
		<div id="opciones">
			<button value="copiar" onclick="stmpujanteAjaxOperacionAttachment('copiar-attachment')"><?php echo __( 'Copiar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('copiar-attachment')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
		
	</div>
	
	<div id="eliminar-attachment" style="display:none">
	
		<h1><?php echo __( 'Eliminar attachment/s', 'stmpujante' ); ?></h1>
		<p id="eliminar-recordatorio-attachment"></p>
		<div id="opciones">
			<button value="eliminar" onclick="stmpujanteAjaxOperacionAttachment('eliminar-attachment')"><?php echo __( 'Eliminar', 'stmpujante' ); ?></button>
			<button value="cancelar" onclick="stmpujanteOcultarOperacion('eliminar-attachment')"><?php echo __( 'Cancelar', 'stmpujante' ); ?></button>
		</div>
	
	</div>
	
	<div id="fondo"></div>
	
	<?php

	////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU //
	//    2.3. Estilos CSS        //
	////////////////////////////////

	?>
	<style>
		.subcarpeta {
			width: 16px;
		}
		.no-subcarpetas {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/vacio.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.abierta {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/reducir.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.cerrada {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/ampliar.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.carpeta-abierta {
			font-weight:bold;
		}
		.icono-abierta {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/abierta.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.icono-cerrada {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/cerrada.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.padre {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/arriba.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
		.hijo {
			width: 16px;
			background-image: url('<?php echo plugin_dir_url(__FILE__) . '/abierta.gif'; ?>');
			background-repeat: no-repeat;
			background-position: center center;
		}
			

	</style>
	<?php

	//////////////////////////////////
	// 2. CREAR PAGINA DE SUBMENU   //
	//    2.4. Funciones JavaScript //
	//////////////////////////////////

	?>
	<script>
	
		///////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                        //
		//    2.4. Funciones JavaScript                      //
		//         2.4.1. Función stmpujanteToggleApertura() //
		///////////////////////////////////////////////////////

		// Con la función stmpujanteToggleApertura() controlamos la visualización de las subcarpetas de la carpeta actual
		// Además, cambiaremos la clase del control para que nos aparezca el icono + o -
		function stmpujanteToggleApertura(id) {

			elemento = document.getElementById('apertura-'+id);
		
			// Primero, comprobamos si tiene subcarpetas.
			if ( elemento.className == 'cerrada' ){
				
				// Eliminamos la clase 'cerrada' y la cambiamos por 'abierta'
				elemento.className = 'abierta';
				
				// Y visualizamos sus hijas
				document.getElementById('hijas-de-'+id).style.display = "table-row";
				
			} else {
				if ( elemento.className == 'abierta' ) {
					
					// Cambiamos clase 'abierta' por 'cerrada'
					elemento.className = 'cerrada';
					
					// Y ocultamos a las hijas
					document.getElementById('hijas-de-'+id).style.display = "none";
				}
			} // El tercer caso sería 'no-subcarpetas' y no hacemos nada
		}

		////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                         //
		//    2.4. Funciones JavaScript                       //
		//         2.4.2. Función stmpujanteToggleSeleccion() //
		////////////////////////////////////////////////////////
		
		// La función stmpujanteToggleSeleccion() nos permite tener un listado de todas las carpetas que están seleccionadas
		// Esto nos permitirá las acciones grupales
		function stmpujanteToggleSeleccion( id ) {
		
			// Cojemos el contenido de 'seleccionadas' y lo pasamos a una matriz
			lista = document.getElementById('seleccionadas').innerHTML;
			matriz = lista.split(",");
			
			// Ahora recorremos toda la matriz, para ver si está la carpeta seleccionada previamente
			var seleccionada=-1;
			for( contador=0; contador<matriz.length; contador++ ) {
				if ( parseInt( matriz[contador] ) == id ) {
					seleccionada = contador;
				}
			}
			
			// Si ya estaba seleccionada, la eliminamos
			if ( seleccionada != -1 ) {
				matriz.splice( seleccionada, 1); // Con delete matriz[seleccionada] se mantiene el elemento vacío
			} else { // Si no estaba seleccionada, la añadimos
				matriz.push(id.toString());
			}
			
			// Volvemos a convertir la matriz en cadena y la actualizamos en 'seleccionadas'
			if ( matriz.length > 0 ) {
				lista = matriz.toString();
			} else {
				lista = '';
			}
			if ( lista.charAt(0) == ',' ) {
				lista = lista.substring( 1, lista.length );
			}
			document.getElementById('seleccionadas').innerHTML = lista;
			
			// Finalmente, si existen seleccionadas, desactivamos 'nueva' y 'editar' de la lista de opciones
			opciones = document.getElementById('operacion-carpetas').getElementsByTagName("option");
			matriz = lista.split(",");
			if ( matriz.length > 1 ) {
				opciones[1].disabled = true;
				opciones[2].disabled = true;
			} else {
				opciones[1].disabled = false;
				opciones[2].disabled = false;
			}
			
		}

		///////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                    //
		//    2.4. Funciones JavaScript                  //
		//         2.4.3. Función stmpujanteToggleFoco() //
		///////////////////////////////////////////////////
		
		// La función stmpujanteToggleFoco() nos ayuda a determinar en qué carpeta se encuentra el foco, para las operaciones
		// Además, nos togglea el grosor del nombre de la carpeta y el icono de carpeta abierta o cerrada
		function stmpujanteToggleFoco(id) {
			
			// La div 'focalizada' contiene el $id de la carpeta con el foco. Lo cambiamos, guardando la anterior
			foco = document.getElementById('focalizada');
			carpetaAntigua = foco.innerHTML;
			foco.innerHTML = id;
			stmpujanteAjaxOperacionAttachment( '', id );

			// Ahora, quitamos las características a la carpeta anterior
			if ( document.getElementById('nombre-'+carpetaAntigua).className == "carpeta-cerrada" ) {
				document.getElementById('nombre-'+carpetaAntigua).className = "carpeta-abierta";
			} else {
				document.getElementById('nombre-'+carpetaAntigua).className = "carpeta-cerrada";
			}
			if ( document.getElementById('icono-'+carpetaAntigua).className == "icono-cerrada" ) {
				document.getElementById('icono-'+carpetaAntigua).className = 'icono-abierta';
			} else {
				document.getElementById('icono-'+carpetaAntigua).className = 'icono-cerrada';
			}
			
			// Y hacemos lo propio con la nueva carpeta focalizada
			if ( document.getElementById('nombre-'+id).className == 'carpeta-cerrada' ) {
				document.getElementById('nombre-'+id).className = 'carpeta-abierta';
			} else {
				document.getElementById('nombre-'+id).className = 'carpeta-cerrada';
			}
			if ( document.getElementById('icono-'+id).className == 'icono-abierta' ) {
				document.getElementById('icono-'+id).className = 'icono-cerrada';
			} else {
				document.getElementById('icono-'+id).className = 'icono-abierta';
			}
			
			// Finalmente, eliminamos los attachments que había seleccionados
			document.getElementById('select_attach').innerHTML = '';
			document.getElementById('seleccionados').innerHTML = 0;
		
		}

		/////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                          //
		//    2.4. Funciones JavaScript                        //
		//         2.4.4. Función stmpujanteOperacionCarpeta() //
		/////////////////////////////////////////////////////////
		
		// La función stmpujanteOperacionCarpeta() nos realiza diversos cometidos:
		// - Primero, controla si la operación sera individual o grupal
		// - Segundo, incluye los comentarios necesarios para que el usuario esté totalmente informado
		// - Finalmente, visualiza la ventana de la operación seleccionada
		function stmpujanteOperacionCarpeta() {
			
			// Averiguamos si será una operación grupal o individual
			lista = document.getElementById('seleccionadas').innerHTML;
			if ( lista == '' ) {
				grupal = false;
			} else {
				grupal = true;
			}
			// Vemos qué operación se ha seleccionado
			operacion = document.getElementById('operacion-carpetas').value;
			
			// Incluimos los comentarios necesarios para informar al usuario
			switch( operacion ) {
				case 'nueva': // Sólo vaciamos el input
					document.getElementById('nuevo-nombre').value = '';
					break;
				case 'editar': // Introducimos en el input el nombre previo de la carpeta
					if ( grupal == false ) {
						carpeta = document.getElementById('focalizada').innerHTML;
					} else {
						matriz = lista.split(",");
						carpeta = matriz[0];
					}
					nombre = document.getElementById('nombre-'+carpeta).innerHTML;
					document.getElementById('editar-nombre').value = nombre;
					break;
				case 'mover': // Indicamos qué carpeta/s va/n a ser movida/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a mover la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a mover las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('mover-recordatorio').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'mover-seleccion' );
					break;
				case 'copiar': // Indicamos qué carpeta/s va/n a ser copiada/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a copiar la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a copiar las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('copiar-recordatorio').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'copiar-seleccion' );
					break;
				case 'eliminar': // Indicamos qué carpeta/s va/n a ser borrada/s
					if ( grupal == false ) {
						cadena = '<?php echo __( 'Va a borrar la carpeta', 'stmpujante' ); ?>: ';
						id = document.getElementById('focalizada').innerHTML;
						carpeta = document.getElementById( 'nombre-' + id ).innerHTML;
						cadena = cadena + carpeta;
					} else {
						cadena = '<?php echo __( 'Va a borrar las siguientes carpetas', 'stmpujante'); ?>:<br>';
						matriz = lista.split(",");
						for ( x = 0; x < matriz.length; x++ ) {
							carpeta = document.getElementById('nombre-'+matriz[x]).innerHTML;
							cadena = cadena + '- ' + carpeta + '<br>';
						}
					}
					document.getElementById('eliminar-recordatorio').innerHTML = cadena;
					break;
			}
			
			// Ahora, creamos las ventanas modales en forma lightbox
			if ( operacion != 'none' ) {
				ventana = document.getElementById( operacion + '-carpeta' );
				ventana.style.position = 'fixed';
				ventana.style.top = '100px';
				ventana.style.left = ((document.body.clientWidth-350) / 2 ) + "px";
				ventana.style.display = 'block';
				ventana.style.padding = '20px';
				ventana.style.backgroundColor = '#bbb';
				ventana.style.border = 'black solid 2px';
			}
			
			// Finalmente, establecemos el foco
			switch ( operacion ) {
				case 'nueva':
					document.getElementById('nuevo-nombre').focus();
					break;
				case 'editar':
					document.getElementById('editar-nombre').focus();
					break;
				case 'mover':
					document.getElementById('mover-seleccion').focus();
					break;
				case 'copiar':
					document.getElementById('copiar-seleccion').focus();
					break;
				case 'eliminar':
					// En este caso no establecemos foco
					break;
			}
		
		}

		///////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                        //
		//    2.4. Funciones JavaScript                      //
		//         2.4.5. Función stmpujanteOpcionesSelect() //
		///////////////////////////////////////////////////////
		
		// La función stmpujanteOpcionesSelect nos creará las opciones de los campos select
		function stmpujanteOpcionesSelect( id ) {
			
			// Primero creamos una matriz con todas las carpetas, gracias al campo 'truco'
			matriz = document.getElementsByClassName('truco');
			var matrizCarpetas = new Array( matriz.length );
			if ( matrizCarpetas > 0 ) {
				matrizCarpetas.splice( 0, matrizCarpetas.length );
			}
			for ( i = 0; i < matriz.length; i++ ) {
				carpeta = matriz[i].innerHTML;
				carpetas = carpeta.split(",");
				matrizCarpetas[i] = [ carpetas[0], carpetas[1] ];
			}
			
			// Averiguamos si será una operación grupal o individual
			lista = document.getElementById('seleccionadas').innerHTML;
			if ( lista == '' ) {
				grupal = false;
			} else {
				grupal = true;
			}

			// Ahora debemos descartar la/s carpeta/s que no corresponda/n
			if ( grupal == false ) {
				actual = document.getElementById('focalizada').innerHTML;
				indice = -1
				for ( i = 0; i < matrizCarpetas.length; i++ ) {
					if ( matrizCarpetas[i][0] == actual ) {
						indice = i;
					}
				}
				if ( indice != -1 ) {
					matrizCarpetas.splice(indice,1);
				}
			} else {
				matrizSeleccionadas = lista.split(",");
				for ( i = 0; i < matrizSeleccionadas.length; i++ ) {
					for ( j = 0; j < matrizCarpetas.length; j++ ) {
						if ( matrizSeleccionadas[i] == matrizCarpetas[j][0] ) {
							matrizCarpetas.splice(j,1);
						}
					}
				}
			}
			
			// Finalmente, con la matrizCarpetas creamos las opciones
			select = document.getElementById( id );
			while ( select.hasChildNodes() ) {
				select.removeChild( select.childNodes[0] );
			}
			for ( i = 0; i < matrizCarpetas.length; i++ ) {
				opcion = document.createElement("option");
				opcion.value = matrizCarpetas[i][0];
				opcion.text = matrizCarpetas[i][1];
				select.appendChild(opcion);
			}
			
		}
		/////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                          //
		//    2.4. Funciones JavaScript                        //
		//         2.4.6. Función stmpujanteOcultarOperacion() //
		/////////////////////////////////////////////////////////
		
		// La función stmpujanteOcultarOperacion simplemente oculta la ventana modal abierta
		function stmpujanteOcultarOperacion( id ) {
			
			ventana = document.getElementById( id );
			ventana.style.display = 'none';
			document.getElementById('operacion-carpetas').selectedIndex = 0;
			document.getElementById('operacion-attachments').selectedIndex = 0;
			
		}
		
		///////////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                                //
		//    2.4. Funciones JavaScript                              //
		//         2.4.8. Función stmpujanteToggleSelectAttachment() //
		///////////////////////////////////////////////////////////////
		
		// La función stmpujanteToggleSelectAttachment() nos permite tener un listado de todos los attachments que están seleccionados
		function stmpujanteToggleSelectAttachment( id ) {
		
			// Cojemos el contenido de 'seleccionadas' y lo pasamos a una matriz
			lista = document.getElementById('select_attach').innerHTML;
			matriz = lista.split(",");
			
			// Ahora recorremos toda la matriz, para ver si está la carpeta seleccionada previamente
			var seleccionada=-1;
			for( contador=0; contador<matriz.length; contador++ ) {
				if ( parseInt( matriz[contador] ) == id ) {
					seleccionada = contador;
				}
			}
			
			// Si ya estaba seleccionada, la eliminamos
			if ( seleccionada != -1 ) {
				matriz.splice( seleccionada, 1); // Con delete matriz[seleccionada] se mantiene el elemento vacío
				// Y cambiamos sus estilos
				document.getElementById('selec-attach-'+id).checked = false;
				document.getElementById('nombre-attachment-'+id).style.fontWeight = 'normal';
				document.getElementById('imagen-attachment-'+id).style.border = 'black solid 0px';
			} else { // Si no estaba seleccionada, la añadimos
				matriz.push(id.toString());
				// Y cambiamos sus estilos
				document.getElementById('selec-attach-'+id).checked = true;
				document.getElementById('nombre-attachment-'+id).style.fontWeight = 'bold';
				document.getElementById('imagen-attachment-'+id).style.border = 'black solid 1px';
			}
			
			// Volvemos a convertir la matriz en cadena y la actualizamos en 'seleccionadas'
			if ( matriz.length > 0 ) {
				lista = matriz.toString();
			} else {
				lista = '';
			}
			if ( lista.charAt(0) == ',' ) {
				lista = lista.substring( 1, lista.length );
			}
			document.getElementById('select_attach').innerHTML = lista;
			document.getElementById('seleccionados').innerHTML = matriz.length;
			
		}
		
		////////////////////////////////////////////////////////////
		// 2. CREAR PAGINA DE SUBMENU                             //
		//    2.4. Funciones JavaScript                           //
		//         2.4.9. Función stmpujanteOperacionAttachment() //
		////////////////////////////////////////////////////////////
		
		// La función stmpujanteOperacionAttachment() nos realiza diversos cometidos:
		// - Primero, incluye los comentarios necesarios para que el usuario esté totalmente informado
		// - Finalmente, visualiza la ventana de la operación seleccionada
		function stmpujanteOperacionAttachment() {
			
			// Averiguamos qué attachments
			lista = document.getElementById('select_attach').innerHTML;

			// Vemos qué operación se ha seleccionado
			operacion = document.getElementById('operacion-attachments').value;
			
			// Incluimos los comentarios necesarios para informar al usuario
			switch( operacion ) {
				case 'mover': // Indicamos qué carpeta/s va/n a ser movida/s
					cadena = '<?php echo __( 'Va a mover el/los siguiente/s attachment/s', 'stmpujante'); ?>:<br>';
					matriz = lista.split(",");
					for ( x = 0; x < matriz.length; x++ ) {
						carpeta = document.getElementById('nombre-attachment-'+matriz[x]).innerHTML;
						cadena = cadena + '- ' + carpeta + '<br>';
					}
					document.getElementById('mover-recordatorio-attachment').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'mover-seleccion-attachment' );
					break;
				case 'copiar': // Indicamos qué carpeta/s va/n a ser copiada/s
					cadena = '<?php echo __( 'Va a copiar el/los siguiente/s attachment/s', 'stmpujante'); ?>:<br>';
					matriz = lista.split(",");
					for ( x = 0; x < matriz.length; x++ ) {
						carpeta = document.getElementById('nombre-attachment-'+matriz[x]).innerHTML;
						cadena = cadena + '- ' + carpeta + '<br>';
					}
					document.getElementById('copiar-recordatorio-attachment').innerHTML = cadena;
					stmpujanteOpcionesSelect( 'copiar-seleccion-attachment' );
					break;
				case 'eliminar': // Indicamos qué carpeta/s va/n a ser borrada/s
					cadena = '<?php echo __( 'Va a borrar el/los siguiente/s attachment/s', 'stmpujante'); ?>:<br>';
					matriz = lista.split(",");
					for ( x = 0; x < matriz.length; x++ ) {
						carpeta = document.getElementById('nombre-attachment-'+matriz[x]).innerHTML;
						cadena = cadena + '- ' + carpeta + '<br>';
					}
					document.getElementById('eliminar-recordatorio-attachment').innerHTML = cadena;
					break;
			}
			
			// Ahora, creamos las ventanas modales en forma lightbox
			if ( operacion != 'none' ) {
				ventana = document.getElementById( operacion + '-attachment' );
				ventana.style.position = 'fixed';
				ventana.style.top = '100px';
				ventana.style.left = ((document.body.clientWidth-350) / 2 ) + "px";
				ventana.style.display = 'block';
				ventana.style.padding = '20px';
				ventana.style.backgroundColor = '#bbb';
				ventana.style.border = 'black solid 2px';
			}
			
			// Finalmente, establecemos el foco
			switch ( operacion ) {
				case 'mover':
					document.getElementById('mover-seleccion-attachment').focus();
					break;
				case 'copiar':
					document.getElementById('copiar-seleccion-attachment').focus();
					break;
				case 'eliminar':
					// En este caso no establecemos foco
					break;
			}
		
		}
			
	</script>
	<?php
	
}

/////////////////////////////////////////////////////////////////////
// 3. FUNCION stmpujante_funcion_recursiva_carpetas( $nivel, $id ) //
// Descripción: Con los parámetros recibidos, busca los terms cuyo //
// padre sea $id y, por cada uno que encuentra, lo mete en la      //
// matriz $stmpujante_carpetas y se llama a si misma.              //
// Inicio creación: 11 / III / 17                                  //
// Finalización: 14 / III / 17                                     //
/////////////////////////////////////////////////////////////////////

function stmpujante_funcion_recursiva_carpetas( $nivel, $id ) {
	
	// Primero accedemos a la matriz $stmpujante_carpetas
	global $stmpujante_carpetas;
	// Y actualizamos el nivel
	$hijos = array();
	// Realizamos la consulta
	$hijos = get_terms( array( 
		'taxonomy' => 'stmpujante_txn', 
		'orderby' => 'name',
		'hide_empty' => 0,
		'parent' => $id 
	) );
	
	if ( count( $hijos ) != 0 ) {
		
		foreach ( $hijos as $hijo ) {
			
			// Por cada hijo encontrado del term, solicitado, realizamos un registro
			$stmpujante_carpetas[] = array(
			
				'id' 			=> $hijo->term_id,
				'nombre' 		=> $hijo->name,
				'nivel' 		=> $nivel,
				'abierta' 		=> 0,
				'seleccionada' 	=> 0,
				'padre' 		=> $hijo->parent,
				'hijos'			=> stmpujante_funcion_recursiva_carpetas( $nivel+1, $hijo->term_id )
				
			);
			
		}
		
	}
	
	// Retorna la cantidad de hijos que tiene la carpeta
	return count( $hijos );
	
}

/////////////////////////////////////////////////////////
// 4. FUNCION stmpujante_funcion_mostrar_carpetas()    //
// Descripción: Crea el árbol de directorios, con      //
// HTML y JS incluidos.                                //
// Posteriormente he visto que mejor hacerla recursiva //
// Inicio creación: 11 / III / 17                      //
// Finalización: 14 / III / 17                         //
/////////////////////////////////////////////////////////

function stmpujante_funcion_mostrar_carpetas( $nivel, $padre, $estado = '', $foco = 0 ) {

	// Recuperamos la matriz ya llena $stmpujante_carpetas
	global $stmpujante_carpetas;
	/*foreach( $estado as $item ) {
		echo $item[0] . ' | ' . $item[1] . ' | ' . $item[2] . '<br>';
	}*/
	$cadena = '';
	// Recorremos la matriz $stmpujante_carpetas buscando las carpetas con el $nivel recibido
	foreach ( $stmpujante_carpetas as $carpeta ) {
		
		if ( $carpeta['nivel'] == $nivel && $carpeta['padre'] == $padre ) {
	
			$cadena .= '<table id="carpeta">';
			$cadena .= '<tr id="carpeta-' . $carpeta['id'] . '" style="height:16px;"><td><table><tr>';

			for ( $i = 1; $i < $nivel; $i++ ) {

				$cadena .='<td class="pasante" style="width:16px;"><td>';

			}
			if ( $nivel > 0 ) {

				$cadena .='<td class="subcarpeta" style="width:16px;"><td>';

			}

			$cadena .='<td class="truco" style="display:none;">' . $carpeta['id'] . ',' . $carpeta['nombre'] . '</td>';

			// Tenemos 4 parámetros: situación ( nueva/abierta/cerrada ), hijos ( sí/no ), uploads ( sí/no ), foco ( sí/no )
			// Esto crea 24 posibilidades
			// Si hemos hecho una operación, vemos cómo estaba antes
			$situacion = 'nueva';
			foreach ( $estado as $item ) {
				if ( $item[0] == $carpeta['id'] ) {
					$situacion = $item[2];
				}
			}
			
			// La apertura, depende de si tiene hijos o no, y en qué situación previa estaba
			if ( $carpeta['hijos'] == 0 ) {
				$clase = 'no-subcarpetas';
			} else {
				$clase = ( $situacion == 'abierta' ) ? 'abierta' : 'cerrada';
			}

			$cadena .='<td id="apertura-' . $carpeta['id'] . '" class="' . $clase . '" onclick="stmpujanteToggleApertura(' . $carpeta['id'] . ');" width="16px"></td>';

			// La selección sólo cambia si es uploads o no
			$seleccion = ( $carpeta['id'] == 0 ) ? ' disabled="true"' : '';
			$cadena .='<td id="seleccion" width="16px"><input type="checkbox" id="seleccion-' . $carpeta['id'] . '" onchange="stmpujanteToggleSeleccion(' . $carpeta['id'] . ');"' . $seleccion . '></td>';

			if ( $carpeta['id'] == $foco ) { // Si tiene el foco

				$cadena .='<td id="nombre-' . $carpeta['id'] . '" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ')" class="carpeta-abierta">' . $carpeta['nombre'] . '</td>';
				$cadena .='<td id="icono-' . $carpeta['id'] . '" class="icono-abierta" width="16px"></td>';

			} else {

				$cadena .='<td id="nombre-' . $carpeta['id'] . '" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ')" class="carpeta-cerrada">' . $carpeta['nombre'] . '</td>';
				$cadena .='<td id="icono-' . $carpeta['id'] . '" class="icono-cerrada" width="16px"></td>';

			}

			$cadena .='</tr></table></td></tr>';
			
			if ( $carpeta['hijos'] != 0 ) {
				
				if ( $clase == 'cerrada' ) {
					
					$cadena .='<tr id="hijas-de-' . $carpeta['id'] . '" style="display: none;">';
					
				} else {
					
					$cadena .='<tr id="hijas-de-' . $carpeta['id'] . '" style="display: table-row;">';
					
				}
				
				$cadena .='<td colspan="' . ( $nivel + 6 ) . '">';

				$cadena .= stmpujante_funcion_mostrar_carpetas( $nivel + 1, intval( $carpeta['id']), $estado, $foco );

				$cadena .= '</td></tr>';
				
			}
			
			$cadena .='</table>';

		}
		
	}
	
	return $cadena;
	
}

//////////////////////////////////////////////////////////
// 5. FUNCION stmpujante_funcion_operaciones_carpetas() //
// Descripción: Muestra el campo select con las         //
// diferentes acciones a realizar con las carpetas.     //
// Fecha creación: 11 / III / 17                        //
// Finalización: 14 / III / 17                          //
//////////////////////////////////////////////////////////

function stmpujante_funcion_operaciones_carpetas() {
	
	?>
	<label><?php echo __( 'Seleccione una operación', 'stmpujante' ) . ' :'; ?></label>
	<select id="operacion-carpetas" onchange="stmpujanteOperacionCarpeta();">
		<option value="none"><?php echo __( 'Seleccione', 'stmpujante' ) . '...'; ?></option>
		<option class="unica" value="nueva"><?php echo __( 'Nueva subcarpeta', 'stmpujante' ); ?></option>
		<option class="individual no-grupal" value="editar"><?php echo __( 'Editar nombre', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="mover"><?php echo __( 'Mover carpeta/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="copiar"><?php echo __( 'Copiar carpeta/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="eliminar"><?php echo __( 'Eliminar carpeta/s', 'stmpujante' ); ?></option>
	</select>
	<?php
	
}

////////////////////////////////////////////////////////////////////////
// 6. Funciones AJAX                                                  //
//    6.1. Función de enqueue de los scripts de AJAX                  //
//    6.2. Función de recepción de datos y devolución de resultados   //
// Fecha creación: 16 / III / 17                                      //
// Finalización: 19 / III / 17                                        //
////////////////////////////////////////////////////////////////////////

// Función para 'encolar' los scripts de AJAX
add_action( 'init', 'stmpujante_funcion_enqueue_scripts' );

function stmpujante_funcion_enqueue_scripts() {
	
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'ajax-script', plugin_dir_url(__FILE__) . 'js/mi_ajax.js' ); // Ahora creo que podemos prescindir de ella
	$title_nonce = wp_create_nonce( 'devolucion_resultado' );
	wp_localize_script( 'ajax-script', 'stmpujante_ajax', array(
	
		'ajax_url' 	=> admin_url('admin-ajax.php'),
		'nonce'		=> $title_nonce
		
	));
	
}

// Función que recibe los datos, los procesa y devuelve el resultado
add_action( 'wp_ajax_operacion_carpeta', 'stmpujante_funcion_modificacion_carpeta' );

function stmpujante_funcion_modificacion_carpeta() {
	
	// Comprobamos la coincidencia del nonce
	check_ajax_referer( 'devolucion_resultado' );
	
	// Extaemos los datos
	$operacion = $_POST['operacion'];
	$foco = $_POST['foco'];
	$seleccion = $_POST['seleccion'];
	$nombre = $_POST['carpeta'];
	$destino = $_POST['destino'];
	$estado = $_POST['estado'];
	
	switch ( $operacion ) {
		
		case 'nueva-carpeta':
			
			$args = array (
				'parent'	=> $foco
			);
			$matriz = wp_insert_term( $nombre, 'stmpujante_txn', $args );
			// Ahora modificamos el estado, para que el padre esté abierto
			foreach ( $estado as $item ) {
				if ( intval($item[0]) == intval($foco) ) {
					$estado[] = [ $item[0] , $item[1] , "abierta" ];
				}
			}
			// Actualizamos el foco
			// $foco = $matriz['term_id']; // No, lo dejamos donde estaba
			break;
			
		case 'editar-carpeta':
			$args = array (
				'name'	=> $nombre
			);
			wp_update_term( $foco, 'stmpujante_txn', $args );
			break;
			
		case 'mover-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				$args = array (
					'parent'	=> $destino
				);
				wp_update_term( $foco, 'stmpujante_txn', $args );
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				break;
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					$args = array (
						'parent'	=> $destino
					);
					wp_update_term( $elemento, 'stmpujante_txn', $args );
				}
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}

				$seleccion = '';
				break;
				
			}
				
		case 'copiar-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				// Necesitamos saber el nombre de la carpeta con el foco
				foreach ( $estado as $item ) {
					if ( $item[0] ==  $foco ) {
						$args = array (
							'parent'	=> $destino
						);
						$creada = wp_insert_term( $item[1], 'stmpujante_txn', $args );
					}
				}
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				// Finalmente, copiamos todos los attachments de $foco a $creada
				$hijos = get_term_children( $foco, 'stmpujante_txn' );
				$stmpujante_attachments_a_copiar = get_posts( array(
					'posts_per_page'	=> -1,
					'post_type'			=> 'attachment',
					'post_status'		=> 'any',
					'tax_query'			=> array( 
						array(
							'taxonomy'		=> 'stmpujante_txn',
							'field'			=> 'id',
							'terms'			=> $foco
						),
						array(
							'taxonomy'		=> 'stmpujante_txn',
							'field'			=> 'id',
							'terms'			=> $hijos,
							'operator'		=> 'NOT IN'
						)
					)
				));
				
				$final = get_term( $creada['term_id'], 'stmpujante_txn');
				foreach( $stmpujante_attachments_a_copiar as $elemento ) {
					wp_add_object_terms( $elemento->ID, $final->slug, 'stmpujante_txn' );
				}
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					foreach ( $estado as $item ) {
						if ( $item[0] == $elemento ) {
							$args = array (
								'parent'	=> $destino
							);
							$creada = wp_insert_term( $item[1], 'stmpujante_txn', $args );
							// Una vez creada cada una, buscamos los attachments vinculados
							$hijos = get_term_children( $item['0'], 'stmpujante_txn' );
							$stmpujante_attachments_a_copiar = get_posts( array(
								'posts_per_page'	=> -1,
								'post_type'			=> 'attachment',
								'post_status'		=> 'any',
								'tax_query'			=> array( 
									array(
										'taxonomy'		=> 'stmpujante_txn',
										'field'			=> 'id',
										'terms'			=> $item['0']
									),
									array(
										'taxonomy'		=> 'stmpujante_txn',
										'field'			=> 'id',
										'terms'			=> $hijos,
										'operator'		=> 'NOT IN'
									)
								)
							));
							// Y los copiamos a la nueva carpeta
							$final = get_term( $creada['term_id'], 'stmpujante_txn');
							foreach( $stmpujante_attachments_a_copiar as $elemento ) {
								wp_add_object_terms( $elemento->ID, $final->slug, 'stmpujante_txn' );
							}
							
						}
					}
				}
				$seleccion = '';
				// Modificamos el estado, para que el destino se abra
				foreach ( $estado as $item ) {
					if ( intval( $item[0] ) == intval( $destino ) ) {
						$estado[] = [ $item[0] , $item[1] , "abierta" ];
					}
				}
				
			}
			break;
			
		case 'eliminar-carpeta':
		
			if ( $seleccion == '' ) {
				
				// Sólo la carpeta con foco
				wp_delete_term( $foco, 'stmpujante_txn' );
				// Ahora, tenemos que eliminar el term de los attachments
				$hijos = get_term_children( $foco, 'stmpujante_txn' );
				$stmpujante_attachments_a_borrar = get_posts( array(
					'posts_per_page'	=> -1,
					'post_type'			=> 'attachment',
					'post_status'		=> 'any',
					'tax_query'			=> array( 
						array(
							'taxonomy'		=> 'stmpujante_txn',
							'field'			=> 'id',
							'terms'			=> $foco
						),
						array(
							'taxonomy'		=> 'stmpujante_txn',
							'field'			=> 'id',
							'terms'			=> $hijos,
							'operator'		=> 'NOT IN'
						)
					)
				));
				foreach( $stmpujante_attachments_a_borrar as $elemento ) {
					$borrada = get_term( $foco, 'stmpujante_txn');
					wp_remove_object_terms( $elemento->ID, $borrada->slug, 'stmpujante_txn' );
				}
				$foco = 0;
				break;
				
			} else {
				
				// La/s carpeta/s seleccionada/s
				$matriz_seleccion = explode ( ',', $seleccion );
				foreach ( $matriz_seleccion as $elemento ) {
					wp_delete_term( $elemento, 'stmpujante_txn' );
					// Ahora, tenemos que eliminar el term de los attachments
					$hijos = get_term_children( $elemento, 'stmpujante_txn' );
					$stmpujante_attachments_a_borrar = get_posts( array(
						'posts_per_page'	=> -1,
						'post_type'			=> 'attachment',
						'post_status'		=> 'any',
						'tax_query'			=> array( 
							array(
								'taxonomy'		=> 'stmpujante_txn',
								'field'			=> 'id',
								'terms'			=> $elemento
							),
							array(
								'taxonomy'		=> 'stmpujante_txn',
								'field'			=> 'id',
								'terms'			=> $hijos,
								'operator'		=> 'NOT IN'
							)
						)
					));
					foreach( $stmpujante_attachments_a_borrar as $item ) {
						$borrada = get_term( $elemento, 'stmpujante_txn');
						wp_remove_object_terms( $item->ID, $borrada->slug, 'stmpujante_txn' );
					}

					if ( $foco == $elemento ) {
						$foco = 0;
					}
				}
				$seleccion = '';
				break;
				
			}
	}

	// Ahora tenemos que volver a crear la matriz $stmpujante_carpetas
	//unset ( $GLOBALS['stmpujante_carpetas'] );
	global $stmpujante_carpetas;
	//$stmpujante_carpetas_dos = array();
	// El primer valor de la matriz $stmpujante_carpetas es 'uploads'
	$stmpujante_carpetas[] = array ( 
		'id' 			=> 0, 
		'nombre' 		=> 'uploads', 
		'nivel' 		=> 0, 
		'abierta' 		=> 1, 
		'seleccionada' 	=> 0, 
		'padre' 		=> 0,
		'hijos'			=> stmpujante_funcion_recursiva_carpetas( 1, 0 ) // La función recursiva nos devuelve si un elemento tiene hijos
	);
	
	// Ahora, creamos la $cadena
	$cadena = stmpujante_funcion_mostrar_carpetas( 0, 0, $estado, $foco );

	// Devolvemos los resultados
	$resultado = '';
	$resultado .= $cadena . '||';
	$resultado .= $foco . '||';
	$resultado .= $seleccion . '||';
	$resultado .= stmpujante_funcion_breadcrumb( $foco );
	
	echo $resultado;
	
	// Finalizamos el evento AJAX
	wp_die();
	
}

// Función que recibe los datos, los procesa y devuelve el resultado
add_action( 'wp_ajax_operacion_attachment', 'stmpujante_funcion_modificacion_attachment' );

function stmpujante_funcion_modificacion_attachment() {
	
	// Comprobamos la coincidencia del nonce
	check_ajax_referer( 'devolucion_resultado' );
	
	// Extaemos los datos
	$operacion = $_POST['operacion'];
	$foco = $_POST['foco'];
	$seleccion = $_POST['seleccion'];
	$destino = $_POST['destino'];
	//$estado = $_POST['estado'];
	
	switch ( $operacion ) {
		case 'mover-attachment':
			// Tenemos que diferenciar si está en uploads
			if ( $foco == 0 ) {
				$final = get_term( $destino, 'stmpujante_txn' );
				$matriz_seleccion = explode( ',', $seleccion );
				foreach( $matriz_seleccion as $elemento ) {
					wp_add_object_terms( $elemento, $final->slug, 'stmpujante_txn' );
				}
			} else {
				$inicio = get_term( $foco, 'stmpujante_txn' );
				$final = get_term( $destino, 'stmpujante_txn' );
				$matriz_seleccion = explode( ',', $seleccion );
				foreach( $matriz_seleccion as $elemento ) {
					wp_add_object_terms( $elemento, $final->slug, 'stmpujante_txn' );
					wp_remove_object_terms( $elemento, $inicio->slug, 'stmpujante_txn' );
				}
			}
			break;
			
		case 'copiar-attachment':
			$final = get_term( $destino, 'stmpujante_txn');
			$matriz_seleccion = explode( ',', $seleccion );
			foreach( $matriz_seleccion as $elemento ) {
				wp_add_object_terms( $elemento, $final->slug, 'stmpujante_txn' );
			}
			break;
			
		case 'eliminar-attachment':
			// No se puede eliminar el término de 'uploads'
			if ( $foco != 0 ) {
				$inicio = get_term( $foco, 'stmpujante_txn' );
				$matriz_seleccion = explode( ',', $seleccion );
				foreach( $matriz_seleccion as $elemento ) {
					wp_remove_object_terms( $elemento, $inicio->slug, 'stmpujante_txn' );
				}
			}
			break;
	}
	
	// Necesitamos rehacer la matriz $stmpujante_carpetas para las operaciones AJAX
	$stmpujante_carpetas[] = array ( 
		'id' 			=> 0, 
		'nombre' 		=> 'uploads', 
		'nivel' 		=> 0, 
		'abierta' 		=> 1, 
		'seleccionada' 	=> 0, 
		'padre' 		=> 0,
		'hijos'			=> stmpujante_funcion_recursiva_carpetas( 1, 0 ) // La función recursiva nos devuelve si un elemento tiene hijos
	);

	$cadena = stmpujante_funcion_mostrar_attachments( $foco );
	
	echo $cadena . '||' . stmpujante_funcion_breadcrumb( $foco );
	
	wp_die();
	
}

//////////////////////////////////////////////////////////////////////////////////
// 7. FUNCION stmpujante_funcion_mostrar_attachments( $foco )                   //
// Descripción: crea la matriz $stmpujante_attachment con los attachments       //
//              vinculados a la carpeta que tiene el $foco                      //
// Devuelve: Cadena con el breadcrumb, el directorio padre y los subdirectorios //
// Inicio: 20 / III / 17                                                        //
// Finalización: (prevista) 21/ III / 17                                        //
//////////////////////////////////////////////////////////////////////////////////

function stmpujante_funcion_mostrar_attachments( $foco ) {
	
	// Necesitaremos acudir a la matriz de las carpetas
	global $stmpujante_carpetas;
	
	// La consulta cambia ligeramente si el foco está en 'uploads', ya que uploads no es un term de la taxonomía
	if ( $foco == 0 ) {
		
		$todas_carpetas = get_terms( array(
			'taxonomy'		=> 'stmpujante_txn',
			'hide_empty'	=> false,
			'fields'			=> 'ids'
		));
		$stmpujante_attachments = get_posts( array(
			'posts_per_page'	=> -1,
			'post_type'			=> 'attachment',
			'post_status'		=> 'any',
			'tax_query'			=> array( array(
				'taxonomy'		=> 'stmpujante_txn',
				'field'			=> 'id',
				'terms'			=> $todas_carpetas,
				'operator'		=> 'NOT IN'
			))
		));
		
	} else {
		
		$hijos = get_term_children( $foco, 'stmpujante_txn' );
		$stmpujante_attachments = get_posts( array(
			'posts_per_page'	=> -1,
			'post_type'			=> 'attachment',
			'post_status'		=> 'any',
			'tax_query'			=> array( 
				array(
					'taxonomy'		=> 'stmpujante_txn',
					'field'			=> 'id',
					'terms'			=> $foco
				),
				array(
					'taxonomy'		=> 'stmpujante_txn',
					'field'			=> 'id',
					'terms'			=> $hijos,
					'operator'		=> 'NOT IN'
				)
			)
		));
		
	}
	
	// Una vez ya tenemos la matriz principal $stmpujante_attachments, procedemos a visualizarla
	$cadena = '<table>';
	
	// Primero irá, si existe, la flecha hacia arriba
	if ( $foco != 0 ) {
		foreach ( $stmpujante_carpetas as $carpeta ) {
			if ( $carpeta['id'] == $foco ) {
				$cadena .='<tr>';
				$cadena .='<td class="nada" style="display:none;"></td>';
				$cadena .='<td class="padre" onclick="stmpujanteToggleFoco(' . $carpeta['padre'] . ');"></td>';
				$cadena .='<td class="nombre" onclick="stmpujanteToggleFoco(' . $carpeta['padre'] . ');">..</td>';
				$cadena .='<td class="nada"></td>';
				$cadena .='</tr>';
			}
		}
	}
	// Luego, si existen, los subdirectorios
	foreach ( $stmpujante_carpetas as $carpeta ) {
		if ( $carpeta['padre'] == $foco && $carpeta['id'] != $foco ) {
			$cadena .='<tr>';
			$cadena .='<td class="nada" style="display:none;"></td>';
			$cadena .='<td class="hijo" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ');"></td>';
			$cadena .='<td class="nombre" onclick="stmpujanteToggleFoco(' . $carpeta['id'] . ');">' . $carpeta['nombre'] . '</td>';
			$cadena .='<td class="nada"></td>';
			$cadena .='</tr>';
		}
	}
	
	// Finalmente, ya podemos mostrar los attachments
	foreach ( $stmpujante_attachments as $attachment ) {
		
		$cadena .= '<tr>';
		$cadena .= '<td class="truco-attach" style="display:none;">';
		$cadena .= $attachment->ID;
		$cadena .= '</td>';
		$cadena .= '<td id="select-attachment" width="16px">';
		$cadena .= '<input type="checkbox" id="selec-attach-' . $attachment->ID . '" onclick="stmpujanteToggleSelectAttachment(' . $attachment->ID .');">';
		$cadena .= '</td>';
		$cadena .= '<td id="nombre-attachment-' . $attachment->ID . '" onclick="stmpujanteToggleSelectAttachment(' . $attachment->ID .');">';
		$cadena .= $attachment->post_title;
		$cadena .= '</td>';
		$cadena .= '<td id="imagen-attachment-' . $attachment->ID . '" onclick="stmpujanteToggleSelectAttachment(' . $attachment->ID .');">';
		$cadena .= '<img src="' . $attachment->guid . '" height="50px">';
		$cadena .= '</td>';
		$cadena .= '</tr>';
	
	}

	$cadena .= '</table>';
	
	return $cadena . '||' . count( $stmpujante_attachments );
	
}

/////////////////////////////////////////////////////////////
// 8. FUNCION stmpujante_funcion_operaciones_attachments() //
// Descripción: Muestra el campo select con las            //
// diferentes acciones a realizar con los attachments.     //
// Fecha creación: 20 / III / 17                           //
// Finalización: 20 / III / 17                             //
/////////////////////////////////////////////////////////////

function stmpujante_funcion_operaciones_attachments() {
	
	?>
	<label><?php echo __( 'Seleccione una operación', 'stmpujante' ) . ' :'; ?></label>
	<select id="operacion-attachments" onchange="stmpujanteOperacionAttachment();">
		<option value="none"><?php echo __( 'Seleccione', 'stmpujante' ) . '...'; ?></option>
		<option class="individual grupal" value="mover"><?php echo __( 'Mover attachment/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="copiar"><?php echo __( 'Copiar attachment/s', 'stmpujante' ); ?></option>
		<option class="individual grupal" value="eliminar"><?php echo __( 'Eliminar attachment/s', 'stmpujante' ); ?></option>
	</select>
	<?php
	
}

//////////////////////////////////////////////////////////////////////////////////
// 9. FUNCION stmpujante_funcion_breadcrumb( $foco )                            //
// Descripción: Crea un breadcrumbs en la parte superior de la ventana de       //
//              attachments, con vínculos a los directorios superiores.         //
// Fecha creación: 20 / III / 17                                                //
// Finalización: (prevista) 21 / III / 17                                       //
//////////////////////////////////////////////////////////////////////////////////

function stmpujante_funcion_breadcrumb( $indice ) {
	
	// Necesitamos utilizar la matriz $stmpujante_carpetas
	global $stmpujante_carpetas;
	$breadcrumb = array();

	if ( $indice != 0 ) {
		
		foreach( $stmpujante_carpetas as $carpeta ) {

			if ( intval($indice) == intval($carpeta['id']) ) {
				
				$breadcrumb[] = array( $carpeta['id'], $carpeta['nombre'] );
				$indice = intval($carpeta['padre']);
				
			}
			
		}
		
	}
	
	// Por último, introducimos 'uploads'
	$breadcrumb[] = [ 0, 'uploads'];
	// Ahora, por comodidad, le damos la vuelta
	$breadcrumb = array_reverse( $breadcrumb );
	
	// Finalmente, generamos la salida
	$cadena = '<strong>' . __( 'Ruta', 'stmpujante' ) . ':</strong> <div style="background:white;">';
	$contador = 0;
	foreach ( $breadcrumb as $item ) {
		
		$contador++;
		if ( $contador < count( $breadcrumb ) ) {
			
			$cadena .= '<a href="#" onclick="stmpujanteToggleFoco(' . $item[0] . ');">' . $item[1] . '</a> -> ';
			
		} else {
			
			$cadena .= $item[1];
			
		}
		
	}
	$cadena .= '</div>';
	
	return $cadena;
	
}
?>