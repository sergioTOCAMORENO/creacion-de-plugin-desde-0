<?php
/* Template Name: Artículo 4 serie plugin */

get_header();

echo "<h2>Ejemplo 3 de la serie 'Hacer un plugin WordPress desde 0'</h2>";

echo "<h3>Primero, los formatos actuales</h3>";

// Primero buscamos los formatos establecidos en el sistema
function stmpujante_formatos_imagenes() {
	
	global $_wp_additional_image_sizes;
		
	$tamanyos = array();
		
	foreach ( get_intermediate_image_sizes() as $tamanyo ) {
		// Buscamos si es alguno de los originales del core de wordpress
		if ( in_array ( $tamanyo, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ) {
			$tamanyos[ $tamanyo ]['width'] = get_option( "{$tamanyo}_size_w" );
			$tamanyos[ $tamanyo ]['height'] = get_option( "{$tamanyo}_size_h" );
			$tamanyos[ $tamanyo ]['crop'] = get_option( "{$tamanyo}_crop" );
		} elseif ( isset( $_wp_additional_image_sizes[ $tamanyo ] ) ) {
			// O bien si es un formato custom (plugin o plantilla)
			$tamanyos[ $tamanyo ] = array(
				'width'		=> $_wp_additional_image_sizes[ $tamanyo ]['width'],
				'height'	=> $_wp_additional_image_sizes[ $tamanyo ]['height'],
				'crop'		=> $_wp_additional_image_sizes[ $tamanyo ]['crop'],
			);
		}
	}
	
	return $tamanyos;
}

// Finalmente, los mostramos por pantalla
echo '<pre>';
print_r( stmpujante_formatos_imagenes() );
echo '</pre>';

// Ahora vamos a por los datos de los attachments
echo "<h3>Datos de los 'attachments'</h3>";

// Establecemos los argumentos de la consulta...
$argumentos = array(
     'posts_per_page' => -1,
     'post_type'      => 'attachment',
     'post_status'    => 'any'
);

// ... y realizamos la consulta, volcándola en una matriz
$stmpujante_attachments = get_posts( $argumentos );

// De cada uno de los elementos de esta matriz vamos a buscar sus metadatos
$stmpujante_metadatos = array();

foreach ( $stmpujante_attachments as $elemento ) {
	
	$stmpujante_metadatos[ $elemento->ID ] = wp_get_attachment_metadata( $elemento->ID );
	
}

// Una vez tenemos todos los datos, creamos la salida por pantalla
// Primero el campo select

?>
Selecciona el attachment:
<select id="seleccion" onchange="selecciona();">
<option value="0" selected="selected">Escoje un attachment</option>
<?php

foreach ( $stmpujante_attachments as $elemento ) {
	
	echo '<option value="' . $elemento->ID . '">' . $elemento->post_title . '</option>';
	
}
?>
</select><br>
<div id="resultado">
<?php
foreach ( $stmpujante_attachments as $elemento ) {
	echo '<div id="elemento-' . $elemento->ID . '" style="display: none;">';
		echo '<div class="attachment" style="float: left;">';
			echo '<p>Datos del attachment:</p>';
			echo '<pre>';
			print_r( $elemento );
			echo '</pre>';
		echo '</div>';
		echo '<div class="metadata" style="float: left;">';
			echo '<p>Metadatos del attachment:</p>';
			echo '<pre>';
			print_r( $stmpujante_metadatos[$elemento->ID] );
			echo '</pre>';
		echo '</div>';
		echo '<div class="imagen" style="float:left;">';
			echo '<p>Imagen del attachment:</p>';
			echo '<img src="' . $elemento->guid . '" width="500px" height="500px">';
		echo '</div>';
	echo '</div>';
}
?>
</div>
<script>
	function selecciona() {
		
		imagenes = document.getElementById('resultado').childNodes;
		
		for ( var i = 0; i < imagenes.length; i++) {
			if ( imagenes[i].style ) {
				imagenes[i].style.display = "none";
			}
		}
		
		indice = document.getElementById('seleccion').value;
		document.getElementById('elemento-'+indice).style.display = "block";
		
	}
</script>
<?php

get_footer();

?>
</body>