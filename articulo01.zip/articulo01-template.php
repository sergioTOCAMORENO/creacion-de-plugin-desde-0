<?php
/* Template Name: Artículo 2 serie plugin */

get_header();

echo "<h2>Ejemplo 1 de la serie 'Hacer un plugin WordPress desde 0'</h2>";

$upload_dir = wp_upload_dir(); // Array of key => value pairs
/*
    $upload_dir now contains something like the following (if successful)
    Array (
        [path] => C:\path\to\wordpress\wp-content\uploads\2017\01
        [url] => http://example.com/wp-content/uploads/2017/01
        [subdir] => /2017/01
        [basedir] => C:\path\to\wordpress\wp-content\uploads
        [baseurl] => http://example.com/wp-content/uploads
        [error] =>
    )
    // Descriptions
    [path] - base directory and sub directory or full path to upload directory.
    [url] - base url and sub directory or absolute URL to upload directory.
    [subdir] - sub directory if uploads use year/month folders option is on.
    [basedir] - path without subdir.
    [baseurl] - URL path without subdir.
    [error] - set to false.
*/

echo '<h3>Datos de wp_upload_dir()</h3><br />';

echo $upload_dir['path'] . '<br />';
echo $upload_dir['url'] . '<br />';
echo $upload_dir['subdir'] . '<br />';
echo $upload_dir['basedir'] . '<br />';
echo $upload_dir['baseurl'] . '<br />';
echo $upload_dir['error'] . '<br />';

$inicio = str_replace( '\\', '/', urldecode( $upload_dir['basedir'] ) );  // Establecemos la dirección inicial

echo "<h4>Contenido de 'uploads'</h4><br />";

listar_directorios_ruta( $inicio ); // Llamamos a la función recursiva con la dirección inicial

function listar_directorios_ruta( $ruta ){
	// abrir un directorio y listarlo recursivo 
	if ( is_dir( $ruta ) ) {
		if ( $dh = opendir( $ruta ) ) {
			echo "<br>Directorio: $ruta";
			while ( ( $file = readdir( $dh ) ) !== false ) {
				//esta línea la utilizaríamos si queremos listar todo lo que hay en el directorio
				//mostraría tanto archivos como directorios
				echo "<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Nombre de archivo: $file : Es un: " . filetype( $ruta . '/' . $file );
				if ( is_dir( $ruta . '/' . $file ) && $file != "." && $file != ".." ){
					//solo si el archivo es un directorio, distinto que "." y ".."
					listar_directorios_ruta( $ruta . '/' . $file . '/' );
				}
			}
			closedir($dh);
		}
	} else {
		echo "<br>No es ruta valida. " . $ruta; 
	}
}

get_footer();

?>
</body>