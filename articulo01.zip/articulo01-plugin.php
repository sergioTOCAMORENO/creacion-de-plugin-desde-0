<?php

/*
Plugin Name: VER DIRECTORIO UPLOADS
Plugin URI: sergiotoca.com
Description: Plugin 1 de la serie de artículos 'Crear un plugin desde 0'
Version: 0.1
Author: Sergio TOCA MORENO
Author URI: sergiotoca.com
Text Domain: stmpili
Domain Path: /idiomas
*/

add_action( 'after_setup_theme', 'copia_plantilla_tema' );
	
function copia_plantilla_tema() {
		
	$plantilla = 'articulo01-template.php';
	$direccionTema = str_replace( '\\', '\/', urldecode( get_template_directory() ) );
		
	if ( file_exists( $direccionTema . '/' . $plantilla ) ) {
			
		return;
			
	} else {
			
		$direccionOrigen = str_replace( '\\', '\/', urldecode( plugin_dir_path( __FILE__ ) ) );
		copy( $direccionOrigen . $plantilla, $direccionTema . '/' . $plantilla );
	}
	
}
